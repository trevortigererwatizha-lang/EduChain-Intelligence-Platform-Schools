"""End-to-end Django tests (need `pip install -r requirements.txt`). Run: pytest tests/test_pipeline.py"""
import pytest

pytest.importorskip("django")
pytest.importorskip("rest_framework")

from django.core.management import call_command  # noqa: E402
from rest_framework.test import APIClient  # noqa: E402

pytestmark = pytest.mark.django_db


@pytest.fixture
def seeded():
    call_command("seed_demo", schools=14, verbosity=0)


def test_publish_records_every_ranking_on_ledger(seeded):
    from blockchain import service
    from rankings.models import RankingRun, SchoolRanking
    assert service.verify_chain()["valid"]
    run = RankingRun.objects.filter(status="published").order_by("-year").first()
    assert run.rankings.count() == 14
    assert all(r.certificate_hash for r in run.rankings.all())
    assert SchoolRanking.objects.filter(run=run, national_rank=1).exists()


def test_tampering_with_a_ranking_or_a_block_is_detected(seeded):
    from blockchain import service
    from blockchain.models import Block
    from rankings import services
    from rankings.models import SchoolRanking
    r = SchoolRanking.objects.filter(run__status="published").first()
    assert services.verify_ranking(r)["verified"]
    r.overall += 5
    r.save()
    assert not services.verify_ranking(r)["verified"]
    b = Block.objects.filter(record_type="ranking").first()
    b.payload = {**b.payload, "overall_score": 99.0}
    b.save()
    assert not service.verify_chain()["valid"]


def test_public_api_and_permissions(seeded):
    c = APIClient()
    assert c.get("/api/v1/rankings/").status_code == 200
    assert c.get("/api/v1/blockchain/verify/").json()["valid"] is True
    assert c.post("/api/v1/rankings/compute/", {"year": 2025}, format="json").status_code in (401, 403)
    assert c.get("/api/v1/analytics/dataset/").status_code in (401, 403)


def test_roles_and_weights(seeded):
    from django.contrib.auth import get_user_model
    from schools.models import School
    U = get_user_model()
    c = APIClient()
    c.force_authenticate(U.objects.get(username="schooladmin"))
    own = U.objects.get(username="schooladmin").school
    other = School.objects.exclude(pk=own.pk).first()
    assert c.get(f"/api/v1/schools/{own.pk}/indicators/").status_code == 200
    assert c.get(f"/api/v1/schools/{other.pk}/indicators/").status_code == 403
    assert c.put("/api/v1/rankings/config/", {"weights": {"academic": 1}}, format="json").status_code == 403
    c.force_authenticate(U.objects.get(username="admin"))
    assert c.put("/api/v1/rankings/config/", {"weights": {"academic": 1, "sports": 1}}, format="json").status_code == 200
    assert c.put("/api/v1/rankings/config/", {"weights": {"nonsense": 1}}, format="json").status_code == 400


def test_csv_hub_permissions_roundtrip_and_locking(seeded):
    import csv
    import io

    from blockchain import service
    from django.contrib.auth import get_user_model
    from django.core.files.uploadedfile import SimpleUploadedFile
    from django.test import Client
    from schools.models import ImportJob, School, SchoolIndicators

    U = get_user_model()
    assert Client().get("/data/").status_code in (302, 403)                 # signed-out users are turned away
    parent = Client(); parent.force_login(U.objects.get(username="parent"))
    assert parent.get("/data/").status_code == 403
    assert parent.get("/data/export/schools.csv").status_code == 403

    c = Client(); c.force_login(U.objects.get(username="ministry"))
    assert c.get("/data/").status_code == 200
    assert c.get("/data/template/indicators.csv").content.startswith(b"\xef\xbb\xbf")

    # an exported schools file re-imports cleanly as updates only
    r = c.post("/data/upload/", {"kind": "schools", "file": SimpleUploadedFile("s.csv", c.get("/data/export/schools.csv").content)})
    assert r.status_code == 200 and b"Every row passed validation" in r.content
    c.post(f"/data/confirm/{ImportJob.objects.latest('created_at').pk}/", {})
    assert School.objects.count() == 14 and ImportJob.objects.latest("created_at").rows_updated == 14

    # verified indicators are locked: re-uploading an existing verified year is reported, not applied
    exported = c.get("/data/export/indicators.csv?year=2025").content.decode("utf-8-sig")
    r = c.post("/data/upload/", {"kind": "indicators", "file": SimpleUploadedFile("i.csv", exported.encode())})
    assert b"already verified and locked" in r.content and b"Every row passed validation" not in r.content

    # the same data for a new year imports and verifies onto the ledger
    rows = list(csv.DictReader(io.StringIO(exported)))
    for row in rows:
        row["year"] = "2026"
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    r = c.post("/data/upload/", {"kind": "indicators", "file": SimpleUploadedFile("n.csv", buf.getvalue().encode())})
    assert b"Every row passed validation" in r.content
    c.post(f"/data/confirm/{ImportJob.objects.latest('created_at').pk}/", {"mode": "verified"})
    assert SchoolIndicators.objects.filter(year=2026, status="verified").count() == 14
    assert service.verify_chain()["valid"]

    # a bad file imports nothing
    before = SchoolIndicators.objects.count()
    for row in rows:
        row["year"] = "2027"
    rows[0]["exam_pass_rate"] = "500"                                       # one impossible value in an otherwise good file
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    r = c.post("/data/upload/", {"kind": "indicators", "file": SimpleUploadedFile("b.csv", buf.getvalue().encode())})
    assert b"Nothing was saved" in r.content and SchoolIndicators.objects.count() == before


def test_every_public_page_renders(seeded):
    from django.test import Client
    c = Client()
    for url in ("/", "/rankings/", "/rankings/?view=cards", "/rankings/?view=compact&sort=sports", "/provinces/",
                "/provinces/Harare/", "/trends/", "/leaderboards/", "/leaderboards/?cat=sports", "/find/",
                "/find/data.json", "/ledger/", "/methodology/", "/verify/", "/compare/", "/compare/?ids=1,2",
                "/rankings/export.csv", "/rankings/?year=abc"):
        r = c.get(url)
        assert r.status_code == 200, (url, r.status_code)
    from schools.models import School
    assert c.get(f"/schools/{School.objects.first().pk}/").status_code == 200
    assert c.get("/early-warning/").status_code in (302, 403)               # staff only
