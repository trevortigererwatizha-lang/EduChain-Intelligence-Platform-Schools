"""Pure tests for CSV validation (no Django needed)."""
import csv
import io
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from schools import csvio  # noqa: E402
from schools.indicators import INDICATOR_FIELDS  # noqa: E402


def _good_indicator_row(**over):
    row = {"registration_number": "S-1", "year": "2025"}
    row.update({f: "50" for f in INDICATOR_FIELDS})
    row.update(enrollment_growth="-2.5", total_enrollment="1,250", national_titles="2", teacher_student_ratio="28")
    row.update(over)
    return row


def _csv(header, rows):
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=header)
    w.writeheader()
    w.writerows(rows)
    return buf.getvalue().encode()


def test_schools_happy_path_and_normalisation():
    data = ("﻿Registration Number,Name,School-Type,Province,District,Latitude,Longitude,Boarding Type\n"
            "A-1,Test High,Government,Harare,Harare,-17.8,31.0,Day School\n"
            "A-2,Hill College,MISSION,Manicaland,Mutare,,,\n").encode("utf-8")
    r = csvio.parse_schools(data)
    assert r.ok, r.errors
    assert r.rows[0]["school_type"] == "government" and r.rows[0]["boarding_type"] == "day"
    assert r.rows[0]["latitude"] == -17.8 and r.rows[1]["latitude"] is None


def test_schools_reports_every_problem_with_line_numbers():
    data = (b"registration_number,name,school_type,province,district,latitude,longitude,email,website\n"
            b"A-1,One,government,P,D,95,31,,\n"
            b"A-1,Dup,government,P,D,,,,\n"
            b"A-3,Three,academy,P,D,,,bad-email,ftp://x\n"
            b"A-4,Four,private,P,D,-10,,,\n")
    r = csvio.parse_schools(data)
    assert not r.ok
    got = {(e["line"], e["field"]) for e in r.errors}
    assert (2, "latitude") in got and (3, "registration_number") in got
    assert (4, "school_type") in got and (4, "email") in got and (4, "website") in got
    assert (5, "latitude") in got  # longitude missing


def test_missing_required_column_is_one_clear_error():
    r = csvio.parse_schools(b"name,province\nX,Y\n")
    assert not r.ok and "Missing column" in r.errors[0]["message"]


def test_indicators_happy_path():
    r = csvio.parse_indicators(_csv(csvio.INDICATOR_COLUMNS, [_good_indicator_row()]))
    assert r.ok, r.errors
    row = r.rows[0]
    assert row["year"] == 2025 and row["enrollment_growth"] == -2.5
    assert row["total_enrollment"] == 1250 and isinstance(row["national_titles"], int)


def test_indicator_validation_rules():
    bad = [_good_indicator_row(exam_pass_rate="101"),            # percent out of range
           _good_indicator_row(registration_number="S-2", national_titles="1.5"),
           _good_indicator_row(registration_number="S-3", teacher_student_ratio="0"),
           _good_indicator_row(registration_number="S-4", literacy_rate=""),
           _good_indicator_row(registration_number="S-5", stem_score="abc"),
           _good_indicator_row(registration_number="S-6", year="1850"),
           _good_indicator_row(registration_number="S-7", annual_revenue="-5")]
    r = csvio.parse_indicators(_csv(csvio.INDICATOR_COLUMNS, bad))
    fields = {(e["line"], e["field"]) for e in r.errors}
    assert fields == {(2, "exam_pass_rate"), (3, "national_titles"), (4, "teacher_student_ratio"),
                      (5, "literacy_rate"), (6, "stem_score"), (7, "year"), (8, "annual_revenue")}
    assert not r.rows


def test_duplicate_school_year_and_missing_columns():
    two = [_good_indicator_row(), _good_indicator_row()]
    r = csvio.parse_indicators(_csv(csvio.INDICATOR_COLUMNS, two))
    assert any("already appears" in e["message"] for e in r.errors)
    r = csvio.parse_indicators(_csv(["registration_number", "year"], [{"registration_number": "S", "year": "2025"}]))
    assert "Missing column" in r.errors[0]["message"] and "exam_pass_rate" in r.errors[0]["message"]


def test_non_utf8_blank_and_header_only_files():
    assert "UTF-8" in csvio.parse_schools(b"\xff\xfe\x00bad").errors[0]["message"]
    assert not csvio.parse_schools(b"").ok
    hdr = ",".join(csvio.SCHOOL_COLUMNS).encode() + b"\n"
    assert "no data rows" in csvio.parse_schools(hdr).errors[0]["message"]


def test_blank_rows_are_skipped_and_error_list_is_capped():
    rows = [_good_indicator_row(registration_number=f"S-{i}", exam_pass_rate="999") for i in range(300)]
    r = csvio.parse_indicators(_csv(csvio.INDICATOR_COLUMNS, rows))
    assert len(r.errors) == csvio.MAX_ERRORS and r.truncated_errors
    blank = _csv(csvio.INDICATOR_COLUMNS, [_good_indicator_row(), {}])
    assert csvio.parse_indicators(blank).ok


def test_export_is_formula_safe_and_roundtrips():
    out = csvio.write_csv(["name", "n"], [["=cmd|' /C calc'!A0", -3.5], ["Normal, with comma", None]])
    assert out.startswith(b"\xef\xbb\xbf")
    rows = list(csv.reader(io.StringIO(out.decode("utf-8-sig"))))
    assert rows[1][0].startswith("'=") and rows[1][1] == "-3.5"       # numbers keep their sign
    assert rows[2] == ["Normal, with comma", ""]


def test_exported_header_is_accepted_by_parser():
    hdr = csvio.write_csv(csvio.SCHOOL_COLUMNS, [["R-1", "N", "private", "day", "P", "D", 1.5, 2.5, "", ""]])
    assert csvio.parse_schools(hdr).ok
    assert any(d["column"] == "exam_pass_rate" for d in csvio.data_dictionary())
