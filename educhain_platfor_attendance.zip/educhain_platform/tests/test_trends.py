import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from analytics import trends  # noqa: E402


def test_movers_use_rank_improvement_and_ignore_new_schools():
    prev = {1: 10, 2: 3, 3: 5}
    curr = {1: 2, 2: 6, 3: 5, 4: 1}          # school 4 is new
    m = trends.movers(prev, curr)
    assert m["risers"] == [(1, 8)] and m["fallers"] == [(2, -3)]


def test_tier_transitions_count_up_down_same():
    prev = {1: "Bronze", 2: "Gold", 3: "Silver", 9: "Gold"}
    curr = {1: "Gold", 2: "Silver", 3: "Silver", 4: "Platinum"}
    t = trends.tier_transitions(prev, curr)
    assert (t["up"], t["down"], t["same"]) == (1, 1, 1)
    assert t["matrix"]["Bronze"]["Gold"] == 1 and t["matrix"]["Gold"]["Silver"] == 1


def test_nearest_and_percent_change():
    near = trends.nearest([0, 0], {1: [3, 4], 2: [1, 1], 3: [10, 10]}, 2)
    assert [n[0] for n in near] == [2, 1] and near[1][1] == pytest.approx(5)
    assert trends.percent_change(50, 60) == 20.0 and trends.percent_change(0, 5) is None


def test_personal_score_reweights_and_handles_zero_weights():
    s = {"academic": 90, "sports": 30}
    assert trends.personal_score(s, {"academic": 1, "sports": 0}) == 90
    assert trends.personal_score(s, {"academic": 1, "sports": 1}) == 60
    assert trends.personal_score(s, {"academic": 0, "sports": 0}) is None
