"""Framework-independent tests. Run with:  pytest tests/test_core.py
These import only the pure modules, so they do not need Django installed."""
import base64
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from analytics import ml  # noqa: E402
from blockchain import ledger  # noqa: E402
from forecasting import engine  # noqa: E402
from rankings import insights, scoring  # noqa: E402
from reports import generators  # noqa: E402
from users import crypto, totp  # noqa: E402

STRONG = dict(exam_pass_rate=95, distinction_rate=70, subject_performance_index=85, university_placement_rate=60,
              stem_score=80, literacy_rate=99, enrollment_growth=8, retention_rate=97, dropout_rate=1,
              teacher_qualification_index=90, teacher_student_ratio=20, professional_development_index=80,
              staff_retention_rate=90, classroom_availability=95, ict_resources=80, laboratory_quality=80,
              library_capacity=70, internet_connectivity=85, revenue_growth=10, budget_utilization=92,
              fee_collection_rate=90, capitation_efficiency=85, national_titles=2, provincial_championships=3,
              athletic_achievements=5, sports_participation_rate=70, science_fair_awards=3, robotics_participation=60,
              research_projects=3, innovation_grants=1, discipline_index=85, counseling_programs=3,
              health_services_index=80, student_satisfaction=88)


def test_default_weights_sum_to_one():
    assert abs(sum(scoring.DEFAULT_WEIGHTS.values()) - 1.0) < 1e-9


def test_scores_in_range_and_overall_matches_manual():
    s = scoring.category_scores(STRONG)
    assert all(0 <= v <= 100 for v in s.values())
    manual = sum(s[c] * w for c, w in scoring.DEFAULT_WEIGHTS.items())
    assert scoring.overall_score(s, scoring.DEFAULT_WEIGHTS) == pytest.approx(manual, abs=1e-3)


def test_empty_indicators_do_not_crash():
    assert scoring.overall_score(scoring.category_scores({}), scoring.DEFAULT_WEIGHTS) >= 0


def test_weight_validation_and_normalisation():
    with pytest.raises(ValueError):
        scoring.validate_weights({"academic": -1})
    with pytest.raises(ValueError):
        scoring.validate_weights({"nonsense": 1})
    with pytest.raises(ValueError):
        scoring.validate_weights({"academic": 0})
    w = scoring.normalise_weights({"academic": 2, "sports": 2})
    assert w["academic"] == 0.5 and w["sports"] == 0.5 and sum(w.values()) == pytest.approx(1)


def test_changing_weights_changes_ranking():
    a = dict(scoring.category_scores(STRONG)); a["sports"] = 0
    b = dict(a); b["sports"] = 100; b["academic"] = 10
    assert scoring.overall_score(a, {"academic": 1}) > scoring.overall_score(b, {"academic": 1})
    assert scoring.overall_score(a, {"sports": 1}) < scoring.overall_score(b, {"sports": 1})


def test_ranks_with_ties_and_groups():
    e = [dict(school_id=1, overall=90, province="A", district="x"),
         dict(school_id=2, overall=90, province="A", district="y"),
         dict(school_id=3, overall=80, province="B", district="z"),
         dict(school_id=4, overall=70, province="A", district="x")]
    scoring.assign_ranks(e)
    assert [x["national_rank"] for x in e] == [1, 1, 3, 4]
    assert e[3]["provincial_rank"] == 3 and e[2]["provincial_rank"] == 1
    assert e[3]["district_rank"] == 2


def test_tiers():
    assert [scoring.tier_for(v) for v in (90, 80, 70, 55, 10)] == ["Platinum", "Gold", "Silver", "Bronze", "Emerging"]


def _chain(n=4, diff=2):
    blocks, prev = [], ledger.GENESIS_PREV
    for i in range(n):
        payload = {"school": i, "score": 50 + i}
        ts = f"2026-01-0{i + 1}T00:00:00+00:00"
        nonce, h = ledger.mine(i, ts, "ranking", payload, prev, diff)
        blocks.append(dict(index=i, timestamp=ts, record_type="ranking", payload=payload, prev_hash=prev,
                           nonce=nonce, hash=h, signature=ledger.sign(h, "k")))
        prev = h
    return blocks


def test_chain_valid_then_tamper_detected():
    blocks = _chain()
    assert ledger.verify_blocks(blocks, key="k")[0]
    blocks[2]["payload"]["score"] = 99
    ok, idx, reason = ledger.verify_blocks(blocks, key="k")
    assert not ok and idx == 2


def test_chain_detects_deleted_block_and_bad_signature():
    blocks = _chain()
    assert not ledger.verify_blocks(blocks[:1] + blocks[2:], key="k")[0]
    assert not ledger.verify_blocks(_chain(), key="wrong")[0]


def test_forecast_trend_and_bounds():
    f = engine.forecast([60, 62, 64, 66, 68, 70], horizon=3, lo=0, hi=100)
    assert f["forecast"][0] > 69 and f["forecast"] == sorted(f["forecast"])
    assert engine.forecast([95, 97, 99, 100], 3, 0, 100)["forecast"][-1] <= 100
    assert engine.forecast([50], 2)["forecast"] == [50.0, 50.0]
    assert len(engine.forecast([50, 55], 2)["forecast"]) == 2
    assert engine.teachers_required([510, 1000]) == [21, 40]


def test_ml_pipeline_runs():
    import numpy as np
    rng = np.random.default_rng(0)
    X = rng.uniform(20, 95, size=(60, 4))
    y = X @ [0.5, 0.2, 0.2, 0.1]
    imp = ml.factor_importance(X, y, ["a", "b", "c", "d"])["random_forest"]
    assert imp[0][0] == "a"
    labels = [scoring.tier_for(v) for v in y]
    res = ml.train_tier_classifier(X, labels)
    assert res["name"] in {"decision_tree", "svm", "neural_network"} and res["cv_accuracy"] > 0.5
    assert len(set(ml.cluster_schools(X, 3))) == 3
    name, preds = ml.predict_next_overall(X, y, X[:3])
    assert len(preds) == 3


def test_insight_sentence_matches_spec_example():
    prev = {"rank": 12, "overall": 60, "scores": {"academic": 60, "enrollment": 60, "sports": 40}}
    curr = {"rank": 4, "overall": 72, "scores": {"academic": 73.8, "enrollment": 69, "sports": 60}}
    text = insights.explain_rank_change("School A", prev, curr)
    assert text.startswith("School A moved from rank 12 to rank 4 because of")
    assert "academic performance" in text


def test_recommendations_and_risks():
    scores = {"academic": 80, "infrastructure": 30, "sports": 70}
    bench = {"academic": 70, "infrastructure": 65, "sports": 68}
    recs = insights.recommendations(scores, bench)
    assert recs[0]["category"] == "infrastructure" and recs[0]["priority"] == "high"
    assert any(r["category"] == "infrastructure" for r in insights.risk_factors(scores))


def test_totp_rfc6238_vector_and_roundtrip():
    secret = base64.b32encode(b"12345678901234567890").decode()
    assert totp.totp(secret, at=59) [-6:] == "287082"  # RFC 6238 SHA-1 test vector (8-digit 94287082)
    s = totp.new_secret()
    assert totp.verify(s, totp.totp(s))
    good = totp.totp(s, at=1_000_000)
    assert totp.verify(s, good, at=1_000_000 + 30)          # one step of clock drift allowed
    assert not totp.verify(s, good, at=1_000_000 + 300)     # but not ten steps
    assert not totp.verify(s, "abcdef", at=0)               # no crash near the epoch


def test_aes256_roundtrip_and_key_length():
    key = base64.b64encode(os.urandom(32)).decode()
    token = crypto.encrypt("secret-value", key)
    assert crypto.decrypt(token, key) == "secret-value" and token != "secret-value"
    with pytest.raises(ValueError):
        crypto.encrypt("x", base64.b64encode(b"short").decode())


def test_report_generators_produce_valid_files():
    rows = [dict(national_rank=1, provincial_rank=1, district_rank=1, school="Test High", province="Harare",
                 district="Harare", tier="Gold", overall=80.1, academic=85, teacher=70, sports=60,
                 certificate_hash="ab" * 32)]
    assert b"Test High" in generators.to_csv(rows)
    assert generators.to_xlsx(rows)[:2] == b"PK"
    assert generators.to_pdf(rows)[:4] == b"%PDF"
