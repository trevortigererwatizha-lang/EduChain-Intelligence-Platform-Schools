from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/<str:version>/", include("api.urls")),
    path("data/", include("schools.urls")),
    path("", include("dashboards.urls")),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
