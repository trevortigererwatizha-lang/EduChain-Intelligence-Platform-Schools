try:
    from .celery import app as celery_app
    __all__ = ("celery_app",)
except ImportError:  # celery not installed (e.g. light local runs)
    pass
