"""Pure ranking maths (no Django imports) so it can be unit-tested anywhere.

Every indicator is converted to a 0-100 sub-score, averaged into a category
score, and the categories are combined with administrator-configurable weights.
"""
import hashlib
import json

CATEGORIES = [
    "academic", "enrollment", "teacher", "infrastructure",
    "finance", "sports", "innovation", "welfare", "community",
]

DEFAULT_WEIGHTS = {
    "academic": 0.35,
    "enrollment": 0.10,
    "teacher": 0.15,
    "infrastructure": 0.10,
    "finance": 0.05,
    "sports": 0.10,
    "innovation": 0.10,
    "welfare": 0.05,
    "community": 0.0,  # reported, but only counts if an administrator gives it weight
}

TIERS = [("Platinum", 85), ("Gold", 75), ("Silver", 65), ("Bronze", 50)]


def _clamp(v, lo=0.0, hi=100.0):
    return max(lo, min(hi, float(v)))


def scale(v, lo, hi):
    """Linearly map lo -> 0 and hi -> 100 (lo > hi gives an inverted scale)."""
    if hi == lo:
        return 0.0
    return _clamp((float(v) - lo) / (hi - lo) * 100.0)


def _mean(xs):
    xs = list(xs)
    return sum(xs) / len(xs)


def category_scores(i):
    """i: dict of indicator values for one school-year -> dict of category scores (0-100)."""
    g = lambda k: float(i.get(k) or 0)
    s = {
        "academic": _mean(g(k) for k in (
            "exam_pass_rate", "distinction_rate", "subject_performance_index",
            "university_placement_rate", "stem_score", "literacy_rate")),
        "enrollment": _mean([
            scale(g("enrollment_growth"), -10, 15),
            g("retention_rate"),
            100 - g("dropout_rate"),
        ]),
        "teacher": _mean([
            g("teacher_qualification_index"),
            scale(g("teacher_student_ratio"), 50, 12),  # fewer pupils per teacher is better
            g("professional_development_index"),
            g("staff_retention_rate"),
        ]),
        "infrastructure": _mean(g(k) for k in (
            "classroom_availability", "ict_resources", "laboratory_quality",
            "library_capacity", "internet_connectivity")),
        "finance": _mean([
            scale(g("revenue_growth"), -10, 20),
            g("budget_utilization"),
            g("fee_collection_rate"),
            g("capitation_efficiency"),
        ]),
        "sports": _mean([
            min(100, g("national_titles") * 25),
            min(100, g("provincial_championships") * 20),
            min(100, g("athletic_achievements") * 10),
            g("sports_participation_rate"),
        ]),
        "innovation": _mean([
            min(100, g("science_fair_awards") * 20),
            g("robotics_participation"),
            min(100, g("research_projects") * 12.5),
            min(100, g("innovation_grants") * 34),
        ]),
        "welfare": _mean([
            g("discipline_index"),
            min(100, g("counseling_programs") * 25),
            g("health_services_index"),
            g("student_satisfaction"),
        ]),
        "community": _mean([
            g("parent_participation"),
            min(100, g("csr_activities") * 20),
            g("community_outreach_score"),
        ]),
    }
    return {k: round(v, 4) for k, v in s.items()}


def validate_weights(weights):
    if not isinstance(weights, dict) or not weights:
        raise ValueError("weights must be a non-empty object")
    unknown = set(weights) - set(CATEGORIES)
    if unknown:
        raise ValueError("unknown categories: " + ", ".join(sorted(unknown)))
    if any(float(v) < 0 for v in weights.values()):
        raise ValueError("weights cannot be negative")
    if sum(float(v) for v in weights.values()) <= 0:
        raise ValueError("at least one weight must be positive")
    return True


def normalise_weights(weights):
    """Return weights for every category, scaled to sum to 1."""
    validate_weights(weights)
    full = {c: float(weights.get(c, 0.0)) for c in CATEGORIES}
    total = sum(full.values())
    return {c: round(v / total, 6) for c, v in full.items()}


def overall_score(scores, weights):
    w = normalise_weights(weights)
    return round(sum(scores.get(c, 0.0) * w[c] for c in CATEGORIES), 4)


def tier_for(score):
    for name, floor in TIERS:
        if score >= floor:
            return name
    return "Emerging"


def assign_ranks(entries):
    """Adds national_rank, provincial_rank, district_rank (ties share a rank).

    entries: list of dicts with school_id, overall, province, district. Mutated in place.
    """
    def rank_group(items, key):
        ordered = sorted(items, key=lambda e: (-round(e["overall"], 4), e["school_id"]))
        prev, rank = None, 0
        for pos, e in enumerate(ordered, 1):
            sc = round(e["overall"], 4)
            if sc != prev:
                rank, prev = pos, sc
            e[key] = rank

    rank_group(entries, "national_rank")
    for field, key in (("province", "provincial_rank"), ("district", "district_rank")):
        groups = {}
        for e in entries:
            gk = (e["province"], e["district"]) if field == "district" else e["province"]
            groups.setdefault(gk, []).append(e)
        for items in groups.values():
            rank_group(items, key)
    return entries


def methodology_document(weights):
    """Human-readable, hashable description of exactly how scores are produced."""
    return {
        "version": "1.0",
        "weights": normalise_weights(weights),
        "tiers": {name: f">= {floor}" for name, floor in TIERS} | {"Emerging": "< 50"},
        "category_inputs": {
            "academic": "mean of pass rate, distinction rate, subject index, university placement, STEM, literacy",
            "enrollment": "mean of scaled enrollment growth (-10..15%), retention, 100 - dropout",
            "teacher": "mean of qualification, scaled pupils-per-teacher (50..12), professional development, staff retention",
            "infrastructure": "mean of classrooms, ICT, laboratories, library, internet",
            "finance": "mean of scaled revenue growth (-10..20%), budget utilisation, fee collection, capitation efficiency",
            "sports": "mean of national titles (x25), provincial titles (x20), achievements (x10), participation",
            "innovation": "mean of science fair awards (x20), robotics participation, research projects (x12.5), grants (x34)",
            "welfare": "mean of discipline, counselling programmes (x25), health services, student satisfaction",
            "community": "mean of parent participation, CSR activities (x20), outreach score",
        },
        "ties": "schools with equal overall score (4 dp) share a rank",
    }


def document_hash(doc):
    blob = json.dumps(doc, sort_keys=True, separators=(",", ":"), default=str).encode()
    return hashlib.sha256(blob).hexdigest()
