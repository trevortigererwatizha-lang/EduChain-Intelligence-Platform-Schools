from django.conf import settings
from django.db import models

from .scoring import DEFAULT_WEIGHTS


class RankingConfig(models.Model):
    """Administrator-editable weights. The active config is used by the next ranking run."""
    name = models.CharField(max_length=100, default="Default")
    weights = models.JSONField(default=dict, help_text="category -> weight; normalised to sum to 1 when used")
    is_active = models.BooleanField(default=False)
    updated_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL,
                                   related_name="+")
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.name}{' (active)' if self.is_active else ''}"

    def save(self, *args, **kwargs):
        if not self.weights:
            self.weights = dict(DEFAULT_WEIGHTS)
        super().save(*args, **kwargs)
        if self.is_active:
            RankingConfig.objects.exclude(pk=self.pk).update(is_active=False)


class RankingRun(models.Model):
    class Status(models.TextChoices):
        DRAFT = "draft", "Draft (awaiting ministry approval)"
        PUBLISHED = "published", "Published and recorded on ledger"
        SUPERSEDED = "superseded", "Superseded"

    year = models.PositiveIntegerField(db_index=True)
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.DRAFT, db_index=True)
    weights = models.JSONField()
    methodology = models.JSONField()
    methodology_hash = models.CharField(max_length=64)
    methodology_block_index = models.PositiveIntegerField(null=True, blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL,
                                   related_name="+")
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL,
                                    related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)
    published_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-year", "-created_at"]

    def __str__(self):
        return f"{self.year} ranking ({self.status})"


class SchoolRanking(models.Model):
    run = models.ForeignKey(RankingRun, on_delete=models.CASCADE, related_name="rankings")
    school = models.ForeignKey("schools.School", on_delete=models.CASCADE, related_name="rankings")
    scores = models.JSONField(help_text="category -> 0-100 score")
    overall = models.FloatField()
    national_rank = models.PositiveIntegerField(db_index=True)
    provincial_rank = models.PositiveIntegerField()
    district_rank = models.PositiveIntegerField()
    previous_rank = models.PositiveIntegerField(null=True, blank=True)
    tier = models.CharField(max_length=12, db_index=True)
    block_index = models.PositiveIntegerField(null=True, blank=True)
    certificate_hash = models.CharField(max_length=64, blank=True, db_index=True)

    class Meta:
        unique_together = [("run", "school")]
        ordering = ["national_rank", "school__name"]

    def __str__(self):
        return f"{self.school} #{self.national_rank} ({self.run.year})"

    @property
    def rank_change(self):
        """Positive = moved up the table."""
        return None if self.previous_rank is None else self.previous_rank - self.national_rank

    def certificate_payload(self):
        """Exactly what is written to (and later compared against) the ledger."""
        return {
            "run_id": self.run_id, "year": self.run.year, "school_id": self.school_id,
            "registration_number": self.school.registration_number, "school_name": self.school.name,
            "overall_score": self.overall, "scores": self.scores,
            "national_rank": self.national_rank, "provincial_rank": self.provincial_rank,
            "district_rank": self.district_rank, "tier": self.tier,
            "methodology_hash": self.run.methodology_hash,
        }
