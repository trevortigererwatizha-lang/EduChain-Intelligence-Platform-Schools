import json

from django.db import transaction
from django.utils import timezone

from blockchain import ledger
from blockchain import service as chain
from blockchain.models import Block
from notifications.services import notify_roles
from schools.models import SchoolIndicators

from . import scoring
from .models import RankingConfig, RankingRun, SchoolRanking

Status = RankingRun.Status


def active_weights():
    cfg = RankingConfig.objects.filter(is_active=True).first()
    return scoring.normalise_weights(cfg.weights if cfg else scoring.DEFAULT_WEIGHTS)


@transaction.atomic
def set_active_weights(weights, user, name="Custom"):
    """Super-admin changes the weights; the change is audited and written to the ledger."""
    normalised = scoring.normalise_weights(weights)
    cfg = RankingConfig.objects.create(name=name, weights=normalised, is_active=True, updated_by=user)
    block = chain.append("config_change", {"weights": normalised, "changed_by": getattr(user, "username", "system"),
                                           "methodology_hash": scoring.document_hash(scoring.methodology_document(normalised))})
    chain.audit(user, "weights_changed", "ranking_config", cfg.pk, {"weights": normalised, "block": block.index})
    return cfg


@transaction.atomic
def compute_run(year, user=None, weights=None):
    """Score and rank every school with VERIFIED data for `year`. Creates a DRAFT run."""
    qs = SchoolIndicators.objects.filter(year=year, status=SchoolIndicators.Status.VERIFIED,
                                         school__is_active=True).select_related("school")
    if not qs.exists():
        raise ValueError(f"No verified indicator data for {year}.")
    w = scoring.normalise_weights(weights) if weights else active_weights()
    entries = []
    for ind in qs:
        sc = scoring.category_scores(ind.as_dict())
        entries.append({"school_id": ind.school_id, "scores": sc, "overall": round(scoring.overall_score(sc, w), 4),
                        "province": ind.school.province, "district": ind.school.district})
    scoring.assign_ranks(entries)

    prev_run = RankingRun.objects.filter(status=Status.PUBLISHED, year__lt=year).order_by("-year").first()
    prev = {r.school_id: r.national_rank for r in prev_run.rankings.all()} if prev_run else {}

    RankingRun.objects.filter(year=year, status=Status.DRAFT).delete()  # replace any earlier draft
    doc = scoring.methodology_document(w)
    run = RankingRun.objects.create(year=year, weights=w, methodology=doc,
                                    methodology_hash=scoring.document_hash(doc), created_by=user)
    SchoolRanking.objects.bulk_create([
        SchoolRanking(run=run, school_id=e["school_id"], scores=e["scores"], overall=e["overall"],
                      national_rank=e["national_rank"], provincial_rank=e["provincial_rank"],
                      district_rank=e["district_rank"], previous_rank=prev.get(e["school_id"]),
                      tier=scoring.tier_for(e["overall"]))
        for e in entries])
    chain.audit(user, "ranking_computed", "ranking_run", run.pk, {"year": year, "schools": len(entries)})
    return run


@transaction.atomic
def publish_run(run, user):
    """Ministry approval: publish the run and write methodology + every school's result to the ledger."""
    if run.status != Status.DRAFT:
        raise ValueError("Only draft runs can be published.")
    RankingRun.objects.filter(year=run.year, status=Status.PUBLISHED).update(status=Status.SUPERSEDED)
    mblock = chain.append("methodology", {"run_id": run.pk, "year": run.year, "weights": run.weights,
                                          "methodology_hash": run.methodology_hash})
    for r in run.rankings.select_related("school", "run"):
        block = chain.append("ranking", r.certificate_payload())
        r.block_index, r.certificate_hash = block.index, block.hash
        r.save(update_fields=["block_index", "certificate_hash"])
    run.status, run.approved_by, run.published_at = Status.PUBLISHED, user, timezone.now()
    run.methodology_block_index = mblock.index
    run.save()
    chain.audit(user, "ranking_published", "ranking_run", run.pk, {"year": run.year, "methodology_block": mblock.index})
    notify_roles(["school_admin", "parent", "researcher"], f"{run.year} school rankings published",
                 "The new national rankings are live and recorded on the EduChain ledger.")
    return run


def verify_ranking(ranking):
    """Check one ranking certificate: chain integrity AND that the DB row still equals what was recorded."""
    chain_status = chain.verify_chain()
    block = Block.objects.filter(index=ranking.block_index).first() if ranking.block_index is not None else None
    expected = json.loads(ledger.canonical(ranking.certificate_payload()))
    payload_ok = bool(block) and block.payload == expected and block.hash == ranking.certificate_hash
    return {
        "verified": bool(chain_status["valid"] and payload_ok),
        "chain_valid": chain_status["valid"],
        "record_matches_ledger": payload_ok,
        "block_index": ranking.block_index,
        "certificate_hash": ranking.certificate_hash,
        "chain_blocks": chain_status["blocks"],
        "reason": chain_status["reason"] if not chain_status["valid"] else ("ok" if payload_ok else "ranking differs from ledger record"),
    }
