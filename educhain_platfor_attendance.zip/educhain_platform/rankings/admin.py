from django.contrib import admin, messages

from . import scoring, services
from .models import RankingConfig, RankingRun, SchoolRanking


@admin.register(RankingConfig)
class RankingConfigAdmin(admin.ModelAdmin):
    list_display = ("name", "is_active", "updated_by", "updated_at")

    def save_model(self, request, obj, form, change):
        if not request.user.is_superuser and request.user.role != "super_admin":
            return self.message_user(request, "Only super administrators can change ranking weights.", messages.ERROR)
        try:
            scoring.validate_weights(obj.weights or scoring.DEFAULT_WEIGHTS)
        except ValueError as e:
            return self.message_user(request, str(e), messages.ERROR)
        obj.updated_by = request.user
        super().save_model(request, obj, form, change)


class SchoolRankingInline(admin.TabularInline):
    model = SchoolRanking
    extra = 0
    can_delete = False
    fields = ("national_rank", "school", "overall", "tier", "certificate_hash")
    readonly_fields = fields

    def has_add_permission(self, request, obj=None):
        return False


@admin.register(RankingRun)
class RankingRunAdmin(admin.ModelAdmin):
    list_display = ("year", "status", "created_by", "approved_by", "published_at")
    list_filter = ("status", "year")
    readonly_fields = ("weights", "methodology", "methodology_hash", "methodology_block_index",
                       "created_by", "approved_by", "published_at")
    inlines = [SchoolRankingInline]
    actions = ["publish_selected"]

    @admin.action(description="Approve and publish to ledger (ministry)")
    def publish_selected(self, request, queryset):
        if not request.user.is_ministry_or_admin:
            return self.message_user(request, "Only ministry officials can approve rankings.", messages.ERROR)
        for run in queryset:
            try:
                services.publish_run(run, request.user)
                self.message_user(request, f"{run} published.")
            except ValueError as e:
                self.message_user(request, f"{run}: {e}", messages.WARNING)
