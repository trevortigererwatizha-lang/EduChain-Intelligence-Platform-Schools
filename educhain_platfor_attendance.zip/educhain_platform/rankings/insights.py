"""Deterministic, template-based explanations, risk flags and recommendations.

This is rule-based text generation, not an LLM: every sentence is derived from
the numbers, so the output is reproducible and auditable.
"""

LABELS = {
    "academic": "academic performance",
    "enrollment": "enrollment health",
    "teacher": "teaching quality and staffing",
    "infrastructure": "infrastructure",
    "finance": "financial management",
    "sports": "sports achievement",
    "innovation": "innovation output",
    "welfare": "student welfare",
    "community": "community engagement",
}

RECOMMENDATIONS = {
    "academic": "Targeted remedial programmes in weakest subjects, past-paper practice, and STEM tutoring.",
    "enrollment": "Review retention and dropout causes; strengthen parent outreach and bursary support.",
    "teacher": "Recruit or retrain to bring pupils-per-teacher towards 25:1 and fund professional development.",
    "infrastructure": "Prioritise classroom capacity, laboratory equipment, ICT devices and internet connectivity.",
    "finance": "Improve fee collection, tighten budget utilisation tracking and audit capitation spending.",
    "sports": "Invest in coaching, equipment and inter-school fixtures to lift participation and titles.",
    "innovation": "Enter science fairs and robotics leagues; apply for innovation grants; start research clubs.",
    "welfare": "Expand counselling and health services; run satisfaction surveys and act on results.",
    "community": "Grow parent participation, school-community projects and CSR partnerships.",
}


def relative_change(old, new):
    if old is None or old <= 0:
        return None
    return (new - old) / old * 100.0


def explain_rank_change(name, prev, curr):
    """prev/curr: {"rank": int, "overall": float, "scores": {category: score}} (prev may be None)."""
    if not prev:
        return (f"{name} is ranked {curr['rank']} nationally with an overall score of "
                f"{curr['overall']:.1f}; there is no earlier ranking to compare against.")
    deltas = []
    for cat, label in LABELS.items():
        rel = relative_change(prev["scores"].get(cat), curr["scores"].get(cat, 0))
        if rel is not None and abs(rel) >= 1:
            deltas.append((cat, label, rel))
    moved = prev["rank"] - curr["rank"]
    if moved == 0:
        head = f"{name} held rank {curr['rank']}"
        picks = sorted(deltas, key=lambda d: -abs(d[2]))[:2]
        if not picks:
            return head + " with little change in its category scores."
        bits = [f"{l} {'rose' if r > 0 else 'fell'} {abs(r):.0f}%" for _, l, r in picks]
        return head + "; " + ", ".join(bits) + "."
    if moved > 0:
        head = f"{name} moved from rank {prev['rank']} to rank {curr['rank']} because of "
        picks = sorted([d for d in deltas if d[2] > 0], key=lambda d: -d[2])[:3]
        bits = [f"a {r:.0f}% improvement in {l}" for _, l, r in picks]
    else:
        head = f"{name} fell from rank {prev['rank']} to rank {curr['rank']} because of "
        picks = sorted([d for d in deltas if d[2] < 0], key=lambda d: d[2])[:3]
        bits = [f"a {abs(r):.0f}% decline in {l}" for _, l, r in picks]
    if not bits:
        return head.replace(" because of ", "") + ", mainly because other schools improved faster."
    if len(bits) > 1:
        text = ", ".join(bits[:-1]) + ", and " + bits[-1]
    else:
        text = bits[0]
    return head + text + "."


def risk_factors(scores, prev_scores=None, floor=50.0, drop_pct=10.0):
    risks = []
    for cat, label in LABELS.items():
        v = scores.get(cat)
        if v is None:
            continue
        if cat != "community" and v < floor:
            risks.append({"category": cat, "level": "high" if v < floor - 15 else "medium",
                          "message": f"{label.capitalize()} score is {v:.0f}, below the {floor:.0f} threshold."})
        if prev_scores:
            rel = relative_change(prev_scores.get(cat), v)
            if rel is not None and rel <= -drop_pct:
                risks.append({"category": cat, "level": "medium",
                              "message": f"{label.capitalize()} fell {abs(rel):.0f}% since the previous ranking."})
    return risks


def recommendations(scores, benchmark, margin=5.0, limit=4):
    """Suggest actions for categories where the school trails the benchmark (e.g. national median)."""
    gaps = []
    for cat in LABELS:
        if cat == "community" and not benchmark.get(cat):
            continue
        gap = benchmark.get(cat, 0) - scores.get(cat, 0)
        if gap > margin:
            gaps.append((gap, cat))
    gaps.sort(reverse=True)
    return [{"category": cat, "priority": "high" if gap > 15 else "medium",
             "gap_to_median": round(gap, 1), "action": RECOMMENDATIONS[cat]}
            for gap, cat in gaps[:limit]]


def executive_summary(name, curr, tier, explanation, risks, recs):
    lines = [f"{name}: rank {curr['rank']} nationally, overall score {curr['overall']:.1f} ({tier} tier).",
             explanation]
    if risks:
        lines.append(f"{len(risks)} risk flag(s), the most serious being: {risks[0]['message']}")
    if recs:
        lines.append("Top recommendation: " + recs[0]["action"])
    return " ".join(lines)
