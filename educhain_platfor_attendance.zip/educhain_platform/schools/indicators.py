"""Single source of truth for indicator field names (no Django imports)."""
GROUPS = {
    "Academic performance": ["exam_pass_rate", "distinction_rate", "subject_performance_index",
                             "university_placement_rate", "stem_score", "literacy_rate"],
    "Enrollment": ["total_enrollment", "enrollment_growth", "retention_rate", "dropout_rate"],
    "Teacher performance": ["teacher_qualification_index", "teacher_student_ratio",
                            "professional_development_index", "staff_retention_rate"],
    "Infrastructure": ["classroom_availability", "ict_resources", "laboratory_quality",
                       "library_capacity", "internet_connectivity"],
    "Financial": ["revenue_growth", "annual_revenue", "budget_utilization", "fee_collection_rate",
                  "capitation_efficiency"],
    "Sports": ["national_titles", "provincial_championships", "athletic_achievements",
               "sports_participation_rate"],
    "Innovation": ["science_fair_awards", "robotics_participation", "research_projects", "innovation_grants"],
    "Community engagement": ["parent_participation", "csr_activities", "community_outreach_score"],
    "Student welfare": ["discipline_index", "counseling_programs", "health_services_index", "student_satisfaction"],
}
INDICATOR_FIELDS = [f for fields in GROUPS.values() for f in fields]

# How each field is validated on CSV import. Everything not listed here is a 0-100 percentage/index.
COUNT_FIELDS = {"total_enrollment", "national_titles", "provincial_championships", "athletic_achievements",
                "science_fair_awards", "research_projects", "innovation_grants", "csr_activities",
                "counseling_programs"}
SIGNED_FIELDS = {"enrollment_growth", "revenue_growth"}        # percent change, may be negative
POSITIVE_FIELDS = {"teacher_student_ratio"}                      # pupils per teacher, > 0
NON_NEGATIVE_FIELDS = {"annual_revenue"}


def field_kind(name):
    if name in COUNT_FIELDS:
        return "count"
    if name in SIGNED_FIELDS:
        return "signed"
    if name in POSITIVE_FIELDS:
        return "positive"
    if name in NON_NEGATIVE_FIELDS:
        return "money"
    return "percent"


KIND_HELP = {
    "percent": "number from 0 to 100",
    "count": "whole number, 0 or more",
    "signed": "percent change; negative allowed (for example -2.5)",
    "positive": "number greater than 0 (pupils per teacher)",
    "money": "number, 0 or more",
}
