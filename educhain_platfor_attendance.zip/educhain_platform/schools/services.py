from django.db import transaction
from django.utils import timezone

from blockchain import service as chain
from notifications.services import notify_roles

from .indicators import INDICATOR_FIELDS
from .models import SchoolIndicators

S = SchoolIndicators.Status


@transaction.atomic
def submit_indicators(school, year, data, user):
    """School admins submit (or resubmit) a year's data. Verified data is locked."""
    obj, _ = SchoolIndicators.objects.get_or_create(school=school, year=year)
    if obj.status == S.VERIFIED:
        raise ValueError("These indicators are already verified and locked.")
    for k, v in data.items():
        if k in INDICATOR_FIELDS:
            setattr(obj, k, v)
    obj.status, obj.submitted_by, obj.review_note = S.SUBMITTED, user, ""
    obj.save()
    chain.audit(user, "indicators_submitted", "school_indicators", obj.pk, {"school": school.pk, "year": year})
    notify_roles(["ministry"], "Data awaiting verification", f"{school.name} submitted {year} indicators.")
    return obj


@transaction.atomic
def verify_indicators(obj, user):
    if obj.status != S.SUBMITTED:
        raise ValueError("Only submitted indicators can be verified.")
    obj.status, obj.verified_by, obj.verified_at = S.VERIFIED, user, timezone.now()
    obj.data_hash = obj.compute_hash()
    obj.save()
    block = chain.append("validation", {
        "school": obj.school.registration_number, "year": obj.year, "data_hash": obj.data_hash,
        "verified_by": getattr(user, "username", "system"),
    })
    chain.audit(user, "indicators_verified", "school_indicators", obj.pk, {"block": block.index})
    return obj


@transaction.atomic
def reject_indicators(obj, user, note=""):
    if obj.status != S.SUBMITTED:
        raise ValueError("Only submitted indicators can be rejected.")
    obj.status, obj.review_note = S.REJECTED, note[:300]
    obj.save()
    chain.audit(user, "indicators_rejected", "school_indicators", obj.pk, {"note": note})
    return obj
