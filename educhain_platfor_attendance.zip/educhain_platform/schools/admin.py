from django.contrib import admin, messages

from django.http import HttpResponse

from . import csvio, services
from .indicators import INDICATOR_FIELDS
from .models import ImportJob, School, SchoolIndicators


def _csv(data, name):
    r = HttpResponse(data, content_type="text/csv; charset=utf-8")
    r["Content-Disposition"] = f'attachment; filename="{name}"'
    return r


@admin.register(School)
class SchoolAdmin(admin.ModelAdmin):
    list_display = ("name", "registration_number", "school_type", "boarding_type", "province", "district", "is_active")
    list_filter = ("school_type", "boarding_type", "province", "is_active")
    search_fields = ("name", "registration_number", "district")
    actions = ["export_selected"]

    @admin.action(description="Download selected schools as CSV")
    def export_selected(self, request, queryset):
        rows = [[getattr(s, c) for c in csvio.SCHOOL_COLUMNS] for s in queryset]
        return _csv(csvio.write_csv(csvio.SCHOOL_COLUMNS, rows), "educhain_schools_selection.csv")


@admin.register(ImportJob)
class ImportJobAdmin(admin.ModelAdmin):
    """Read-only history of CSV uploads. Upload new files from the Data hub page (/data/)."""
    list_display = ("created_at", "kind", "filename", "status", "user", "rows_total", "rows_created", "rows_updated")
    list_filter = ("kind", "status")
    exclude = ("raw",)

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False


@admin.register(SchoolIndicators)
class SchoolIndicatorsAdmin(admin.ModelAdmin):
    list_display = ("school", "year", "status", "verified_by", "verified_at")
    list_filter = ("status", "year", "school__province")
    search_fields = ("school__name",)
    readonly_fields = ("data_hash", "verified_by", "verified_at")
    actions = ["verify_selected", "reject_selected", "export_selected"]

    @admin.action(description="Download selected indicators as CSV")
    def export_selected(self, request, queryset):
        header = csvio.INDICATOR_COLUMNS + ["status"]
        rows = [[i.school.registration_number, i.year] + [getattr(i, f) for f in INDICATOR_FIELDS] + [i.status]
                for i in queryset.select_related("school")]
        return _csv(csvio.write_csv(header, rows), "educhain_indicators_selection.csv")

    def get_readonly_fields(self, request, obj=None):
        ro = list(super().get_readonly_fields(request, obj))
        if obj and obj.status == SchoolIndicators.Status.VERIFIED:  # verified data is locked
            ro += [f.name for f in obj._meta.fields if f.name not in ro]
        return ro

    @admin.action(description="Verify selected (ministry) and record on ledger")
    def verify_selected(self, request, queryset):
        if not request.user.is_ministry_or_admin:
            return self.message_user(request, "Only ministry officials can verify data.", messages.ERROR)
        done = 0
        for obj in queryset:
            try:
                services.verify_indicators(obj, request.user)
                done += 1
            except ValueError as e:
                self.message_user(request, f"{obj}: {e}", messages.WARNING)
        self.message_user(request, f"{done} record(s) verified.")

    @admin.action(description="Reject selected (ministry)")
    def reject_selected(self, request, queryset):
        if not request.user.is_ministry_or_admin:
            return self.message_user(request, "Only ministry officials can reject data.", messages.ERROR)
        for obj in queryset:
            try:
                services.reject_indicators(obj, request.user)
            except ValueError as e:
                self.message_user(request, f"{obj}: {e}", messages.WARNING)
