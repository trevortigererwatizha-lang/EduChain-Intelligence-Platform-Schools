import hashlib
import json

from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models

from .indicators import INDICATOR_FIELDS


class School(models.Model):
    class SchoolType(models.TextChoices):
        GOVERNMENT = "government", "Government"
        PRIVATE = "private", "Private"
        MISSION = "mission", "Mission"

    class Boarding(models.TextChoices):
        BOARDING = "boarding", "Boarding"
        DAY = "day", "Day school"

    name = models.CharField(max_length=200)
    registration_number = models.CharField(max_length=50, unique=True)
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    school_type = models.CharField(max_length=20, choices=SchoolType.choices)
    boarding_type = models.CharField(max_length=20, choices=Boarding.choices, default=Boarding.DAY)
    province = models.CharField(max_length=80, db_index=True)
    district = models.CharField(max_length=80, db_index=True)
    email = models.EmailField(blank=True)
    website = models.URLField(blank=True)
    logo = models.ImageField(upload_to="logos/", blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class ImportJob(models.Model):
    """One CSV upload: validated first (previewed), then committed or discarded. Kept as an audit record."""

    class Kind(models.TextChoices):
        SCHOOLS = "schools", "Schools"
        INDICATORS = "indicators", "Indicators"

    class Status(models.TextChoices):
        PREVIEWED = "previewed", "Validated, awaiting confirmation"
        COMMITTED = "committed", "Imported"
        FAILED = "failed", "Failed"

    kind = models.CharField(max_length=12, choices=Kind.choices)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PREVIEWED)
    mode = models.CharField(max_length=10, blank=True, help_text="indicators only: submitted or verified")
    filename = models.CharField(max_length=200)
    sha256 = models.CharField(max_length=64)
    raw = models.TextField(blank=True, help_text="uploaded text; cleared once imported")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL, related_name="+")
    rows_total = models.PositiveIntegerField(default=0)
    rows_created = models.PositiveIntegerField(default=0)
    rows_updated = models.PositiveIntegerField(default=0)
    errors = models.JSONField(default=list, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.kind} import {self.filename} ({self.status})"


def _pct():
    return models.FloatField(default=0, validators=[MinValueValidator(0), MaxValueValidator(100)])


def _count():
    return models.PositiveIntegerField(default=0)


class SchoolIndicators(models.Model):
    """One school's indicators for one year. Only VERIFIED rows are ranked."""

    class Status(models.TextChoices):
        DRAFT = "draft", "Draft"
        SUBMITTED = "submitted", "Submitted"
        VERIFIED = "verified", "Verified"
        REJECTED = "rejected", "Rejected"

    school = models.ForeignKey(School, on_delete=models.CASCADE, related_name="indicators")
    year = models.PositiveIntegerField(db_index=True)
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.DRAFT, db_index=True)
    submitted_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL,
                                     related_name="+")
    verified_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL,
                                    related_name="+")
    verified_at = models.DateTimeField(null=True, blank=True)
    review_note = models.CharField(max_length=300, blank=True)
    data_hash = models.CharField(max_length=64, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    # Academic performance
    exam_pass_rate = _pct()
    distinction_rate = _pct()
    subject_performance_index = _pct()
    university_placement_rate = _pct()
    stem_score = _pct()
    literacy_rate = _pct()
    # Enrollment
    total_enrollment = _count()
    enrollment_growth = models.FloatField(default=0, help_text="Percent change year on year")
    retention_rate = _pct()
    dropout_rate = _pct()
    # Teachers
    teacher_qualification_index = _pct()
    teacher_student_ratio = models.FloatField(default=30, help_text="Pupils per teacher")
    professional_development_index = _pct()
    staff_retention_rate = _pct()
    # Infrastructure
    classroom_availability = _pct()
    ict_resources = _pct()
    laboratory_quality = _pct()
    library_capacity = _pct()
    internet_connectivity = _pct()
    # Financial
    revenue_growth = models.FloatField(default=0, help_text="Percent change year on year")
    annual_revenue = models.FloatField(default=0, help_text="Used for forecasting, not scored")
    budget_utilization = _pct()
    fee_collection_rate = _pct()
    capitation_efficiency = _pct()
    # Sports
    national_titles = _count()
    provincial_championships = _count()
    athletic_achievements = _count()
    sports_participation_rate = _pct()
    # Innovation
    science_fair_awards = _count()
    robotics_participation = _pct()
    research_projects = _count()
    innovation_grants = _count()
    # Community engagement
    parent_participation = _pct()
    csr_activities = _count()
    community_outreach_score = _pct()
    # Student welfare
    discipline_index = _pct()
    counseling_programs = _count()
    health_services_index = _pct()
    student_satisfaction = _pct()

    class Meta:
        unique_together = [("school", "year")]
        ordering = ["-year", "school__name"]
        verbose_name_plural = "school indicators"

    def __str__(self):
        return f"{self.school} {self.year} ({self.status})"

    def as_dict(self):
        return {f: getattr(self, f) for f in INDICATOR_FIELDS}

    def compute_hash(self):
        blob = json.dumps({"school": self.school.registration_number, "year": self.year, **self.as_dict()},
                          sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(blob.encode()).hexdigest()

    @property
    def integrity_ok(self):
        """True if verified data still matches the hash that was recorded on the ledger."""
        return self.status == self.Status.VERIFIED and self.data_hash == self.compute_hash()
