"""Apply validated CSV rows to the database. All-or-nothing: one bad row means nothing is saved."""
import hashlib

from django.db import transaction
from django.utils import timezone

from blockchain import service as chain
from notifications.services import notify_roles

from . import csvio, services
from .indicators import INDICATOR_FIELDS
from .models import ImportJob, School, SchoolIndicators

SCHOOL_FIELDS = ["name", "school_type", "boarding_type", "province", "district", "latitude", "longitude",
                 "email", "website"]
S = SchoolIndicators.Status


def start_preview(kind, filename, data, user):
    """Validate an upload and store it as a PREVIEWED job. Returns (job, parse_result, plan)."""
    parser = csvio.parse_schools if kind == ImportJob.Kind.SCHOOLS else csvio.parse_indicators
    res = parser(data)
    plan = _plan(kind, res.rows, res.errors) if not res.errors else None
    text = data if isinstance(data, str) else data.decode("utf-8-sig", errors="replace")
    problems = plan["problems"] if plan else []
    clean = res.ok and not problems
    job = ImportJob.objects.create(
        kind=kind, filename=(filename or "upload.csv")[:200], sha256=hashlib.sha256(text.encode()).hexdigest(),
        raw=text if clean else "", user=user, rows_total=res.total_rows, errors=(res.errors + problems)[:200],
        status=ImportJob.Status.PREVIEWED if clean else ImportJob.Status.FAILED)
    chain.audit(user, "csv_validated", "import_job", job.pk, {"kind": kind, "rows": res.total_rows,
                                                             "errors": len(res.errors)})
    return job, res, plan


def _plan(kind, rows, errors):
    """What committing would do (counts only), plus row-level problems that need the database to detect."""
    if kind == ImportJob.Kind.SCHOOLS:
        existing = set(School.objects.filter(registration_number__in=[r["registration_number"] for r in rows])
                       .values_list("registration_number", flat=True))
        return {"create": sum(r["registration_number"] not in existing for r in rows),
                "update": sum(r["registration_number"] in existing for r in rows), "problems": []}
    schools = {s.registration_number: s for s in
               School.objects.filter(registration_number__in={r["registration_number"] for r in rows})}
    have = {(i.school.registration_number, i.year): i.status for i in
            SchoolIndicators.objects.filter(school__in=schools.values()).select_related("school")}
    plan = {"create": 0, "update": 0, "problems": []}
    for r in rows:
        key = (r["registration_number"], r["year"])
        if r["registration_number"] not in schools:
            plan["problems"].append({"line": r["_line"], "field": "registration_number",
                                     "message": f"No school with registration number '{r['registration_number']}'. Import schools first."})
        elif have.get(key) == S.VERIFIED:
            plan["problems"].append({"line": r["_line"], "field": "year",
                                     "message": f"{r['registration_number']} {r['year']} is already verified and locked."})
        elif key in have:
            plan["update"] += 1
        else:
            plan["create"] += 1
    return plan


@transaction.atomic
def commit(job, user, mode="submitted"):
    """Re-validate the stored text (never trusting the earlier preview) and import it."""
    if job.status != ImportJob.Status.PREVIEWED or not job.raw:
        raise ValueError("This upload is not waiting for confirmation.")
    if job.kind == ImportJob.Kind.SCHOOLS:
        res = csvio.parse_schools(job.raw)
        problems = []
    else:
        res = csvio.parse_indicators(job.raw)
        problems = _plan(job.kind, res.rows, res.errors)["problems"] if not res.errors else []
    if res.errors or problems:
        raise ValueError("The file no longer passes validation. Upload it again.")
    created = updated = 0
    if job.kind == ImportJob.Kind.SCHOOLS:
        for r in res.rows:
            _, was_created = School.objects.update_or_create(
                registration_number=r["registration_number"], defaults={f: r[f] for f in SCHOOL_FIELDS})
            created += was_created
            updated += not was_created
    else:
        schools = {s.registration_number: s for s in School.objects.all()}
        for r in res.rows:
            school = schools[r["registration_number"]]
            obj, was_created = SchoolIndicators.objects.get_or_create(school=school, year=r["year"])
            for f in INDICATOR_FIELDS:
                setattr(obj, f, r[f])
            obj.status, obj.submitted_by, obj.review_note = S.SUBMITTED, user, ""
            obj.save()
            created += was_created
            updated += not was_created
            if mode == "verified":
                services.verify_indicators(obj, user)  # writes each verification to the ledger
        if mode != "verified":
            notify_roles(["ministry"], "Data awaiting verification",
                         f"{len(res.rows)} indicator row(s) were imported from CSV and need verification.")
    job.status, job.mode, job.raw = ImportJob.Status.COMMITTED, mode if job.kind == "indicators" else "", ""
    job.rows_created, job.rows_updated = created, updated
    job.save()
    chain.audit(user, "csv_imported", "import_job", job.pk,
                {"kind": job.kind, "created": created, "updated": updated, "mode": job.mode,
                 "at": timezone.now().isoformat()})
    return job
