"""Data hub: CSV templates, exports and validated uploads for ministry officials and administrators."""
from functools import wraps

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from analytics.services import published_run
from blockchain import service as chain
from rankings.models import RankingRun
from rankings.scoring import CATEGORIES

from . import csvio, importer
from .indicators import INDICATOR_FIELDS
from .models import ImportJob, School, SchoolIndicators


def staff_only(view):
    @wraps(view)
    @login_required
    def wrapper(request, *args, **kwargs):
        if not request.user.is_ministry_or_admin:
            raise PermissionDenied("The data hub is for ministry officials and administrators.")
        return view(request, *args, **kwargs)
    return wrapper


def _csv_response(data, filename):
    resp = HttpResponse(data, content_type="text/csv; charset=utf-8")
    resp["Content-Disposition"] = f'attachment; filename="{filename}"'
    return resp


@staff_only
def hub(request):
    jobs = ImportJob.objects.select_related("user")[:12]
    years = sorted(set(SchoolIndicators.objects.values_list("year", flat=True)), reverse=True)
    counts = {s: SchoolIndicators.objects.filter(status=s).count() for s in SchoolIndicators.Status.values}
    return render(request, "schools/hub.html", {
        "jobs": jobs, "indicator_years": years,
        "ranking_years": sorted(set(RankingRun.objects.values_list("year", flat=True)), reverse=True),
        "years": [], "school_count": School.objects.count(), "indicator_counts": counts,
        "dictionary": csvio.data_dictionary(), "nav": "data"})


@staff_only
def template_csv(request, kind):
    if kind == "schools":
        return _csv_response(csvio.write_csv(csvio.SCHOOL_COLUMNS, []), "educhain_schools_template.csv")
    if kind == "indicators":
        return _csv_response(csvio.write_csv(csvio.INDICATOR_COLUMNS, []), "educhain_indicators_template.csv")
    raise PermissionDenied("Unknown template.")


@staff_only
def export_csv(request, kind):
    g = request.GET
    if kind == "schools":
        qs = School.objects.order_by("registration_number")
        rows = [[getattr(s, c) for c in csvio.SCHOOL_COLUMNS] for s in qs]
        header, name = csvio.SCHOOL_COLUMNS, "educhain_schools.csv"
    elif kind == "indicators":
        qs = SchoolIndicators.objects.select_related("school").order_by("year", "school__registration_number")
        if g.get("year", "").isdigit():
            qs = qs.filter(year=int(g["year"]))
        if g.get("status") in SchoolIndicators.Status.values:
            qs = qs.filter(status=g["status"])
        header = csvio.INDICATOR_COLUMNS + ["status"]
        rows = [[i.school.registration_number, i.year] + [getattr(i, f) for f in INDICATOR_FIELDS] + [i.status]
                for i in qs]
        name = "educhain_indicators.csv"
    elif kind == "rankings":
        run = published_run(g.get("year")) or RankingRun.objects.order_by("-year").first()
        if not run:
            messages.error(request, "There are no ranking runs to export yet.")
            return redirect("schools:hub")
        header = (["year", "registration_number", "school", "province", "district", "school_type", "tier", "overall",
                   "national_rank", "provincial_rank", "district_rank", "previous_rank"] + CATEGORIES +
                  ["certificate_hash", "run_status"])
        rows = [[run.year, r.school.registration_number, r.school.name, r.school.province, r.school.district,
                 r.school.school_type, r.tier, round(r.overall, 4), r.national_rank, r.provincial_rank,
                 r.district_rank, r.previous_rank] + [round(r.scores.get(c, 0), 4) for c in CATEGORIES] +
                [r.certificate_hash, run.status] for r in run.rankings.select_related("school")]
        name = f"educhain_rankings_{run.year}.csv"
    else:
        raise PermissionDenied("Unknown export.")
    chain.audit(request.user, "csv_exported", kind, "", {"rows": len(rows), "filters": dict(g.items())}, request)
    return _csv_response(csvio.write_csv(header, rows), name)


@staff_only
@require_POST
def upload(request):
    kind = request.POST.get("kind")
    f = request.FILES.get("file")
    if kind not in ImportJob.Kind.values:
        messages.error(request, "Choose whether the file contains schools or indicators.")
        return redirect("schools:hub")
    if not f:
        messages.error(request, "Choose a CSV file to upload.")
        return redirect("schools:hub")
    if f.size > csvio.MAX_BYTES:
        messages.error(request, "That file is larger than 5 MB. Split it into smaller files.")
        return redirect("schools:hub")
    job, res, plan = importer.start_preview(kind, f.name, f.read(), request.user)
    errors = list(res.errors) + (plan["problems"] if plan else [])
    fields = csvio.SCHOOL_COLUMNS if kind == "schools" else csvio.INDICATOR_COLUMNS[:10]
    return render(request, "schools/preview.html", {
        "job": job, "res": res, "plan": plan, "errors": errors[:csvio.MAX_ERRORS], "years": [],
        "fields": fields, "sample_rows": [[row.get(f, "") for f in fields] for row in res.rows[:6]],
        "error_total": len(errors), "blocked": bool(errors) or not res.rows, "nav": "data",
        "extra_columns": max(0, len(csvio.INDICATOR_COLUMNS) - len(fields)) if kind == "indicators" else 0})


@staff_only
@require_POST
def confirm(request, pk):
    job = get_object_or_404(ImportJob, pk=pk, user=request.user)
    mode = request.POST.get("mode", "submitted")
    if mode not in ("submitted", "verified"):
        mode = "submitted"
    try:
        importer.commit(job, request.user, mode)
    except ValueError as e:
        messages.error(request, str(e))
        return redirect("schools:hub")
    what = "school" if job.kind == "schools" else "indicator"
    msg = f"Imported {job.rows_created} new and {job.rows_updated} updated {what} record(s)."
    if job.kind == "indicators":
        msg += " They are verified and on the ledger." if mode == "verified" else " They are waiting for verification."
    messages.success(request, msg)
    return redirect("schools:hub")


@staff_only
@require_POST
def discard(request, pk):
    job = get_object_or_404(ImportJob, pk=pk, user=request.user, status=ImportJob.Status.PREVIEWED)
    job.raw = ""
    job.status = ImportJob.Status.FAILED
    job.errors = [{"line": 0, "field": "", "message": "Discarded before importing."}]
    job.save()
    messages.info(request, "Upload discarded. Nothing was changed.")
    return redirect("schools:hub")
