"""Create SYNTHETIC demo data: invented schools, three years of indicators, users, and published rankings.

    python manage.py seed_demo            # adds demo data (skips if schools already exist)
    python manage.py seed_demo --reset    # wipes schools/rankings/ledger first (demo databases only!)
"""
import numpy as np
from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand

from blockchain.models import AuditLog, Block
from rankings import services as rk
from rankings.models import RankingConfig, RankingRun
from schools import services as sch
from schools.models import School, SchoolIndicators

PLACES = {  # province -> (districts, approx lat, lng)
    "Harare": (["Harare"], -17.83, 31.05),
    "Bulawayo": (["Bulawayo"], -20.15, 28.58),
    "Manicaland": (["Mutare", "Chipinge"], -18.97, 32.67),
    "Mashonaland West": (["Chinhoyi"], -17.36, 30.20),
    "Mashonaland East": (["Marondera"], -18.19, 31.55),
    "Mashonaland Central": (["Bindura"], -17.30, 31.33),
    "Masvingo": (["Masvingo"], -20.07, 30.83),
    "Midlands": (["Gweru"], -19.45, 29.82),
    "Matabeleland North": (["Hwange"], -18.37, 26.50),
    "Matabeleland South": (["Gwanda"], -20.94, 29.00),
}
BASES = ["Kopje View", "Acacia Park", "Baobab Hill", "Msasa Ridge", "Mopane Valley", "Zambezi Heights",
         "Limpopo Grove", "Njanja Hills", "Matopos View", "Kariba Lake", "Nyanga Peak", "Sabi Plains"]
SUFFIX = ["High School", "Secondary School", "College", "Academy"]
YEARS = [2023, 2024, 2025]
DEMO_PASSWORD = "educhain-demo-2026"


def _indicators(rng, q, trend, t):
    def pct(base, spread=6):
        return float(np.clip(rng.normal(base + trend * t, spread), 5, 100))

    def cnt(lam):
        return int(rng.poisson(max(lam, 0.05)))

    enroll = int(rng.uniform(300, 1400) * (1 + 0.03 * t))
    return dict(
        exam_pass_rate=pct(q + 8), distinction_rate=pct(q - 25), subject_performance_index=pct(q),
        university_placement_rate=pct(q - 30), stem_score=pct(q - 5), literacy_rate=float(min(100, q * 0.3 + 70)),
        total_enrollment=enroll, enrollment_growth=float(rng.uniform(-3, 8) + trend / 2),
        retention_rate=float(min(99, pct(q + 25))), dropout_rate=float(max(0.5, 15 - q / 8 + rng.normal(0, 1))),
        teacher_qualification_index=pct(q + 10), teacher_student_ratio=float(np.clip(55 - q * 0.4 + rng.normal(0, 3), 14, 60)),
        professional_development_index=pct(q - 5), staff_retention_rate=pct(q + 15),
        classroom_availability=pct(q + 10), ict_resources=pct(q - 15), laboratory_quality=pct(q - 15),
        library_capacity=pct(q - 10), internet_connectivity=pct(q - 10),
        revenue_growth=float(rng.normal(q / 10, 4)), annual_revenue=float(enroll * rng.uniform(150, 900)),
        budget_utilization=pct(q + 15), fee_collection_rate=pct(q + 10), capitation_efficiency=pct(q + 5),
        national_titles=cnt((q - 55) / 25), provincial_championships=cnt((q - 35) / 18),
        athletic_achievements=cnt((q - 30) / 9), sports_participation_rate=pct(q),
        science_fair_awards=cnt((q - 35) / 12), robotics_participation=pct(q - 25),
        research_projects=cnt((q - 40) / 10), innovation_grants=cnt((q - 55) / 30),
        parent_participation=pct(q - 5), csr_activities=cnt((q - 30) / 15), community_outreach_score=pct(q - 10),
        discipline_index=pct(q + 10), counseling_programs=cnt((q - 20) / 20), health_services_index=pct(q - 5),
        student_satisfaction=pct(q),
    )


class Command(BaseCommand):
    help = "Create synthetic demo schools, indicators, users and published rankings"

    def add_arguments(self, parser):
        parser.add_argument("--reset", action="store_true", help="delete existing demo data first")
        parser.add_argument("--schools", type=int, default=40)

    def handle(self, *args, **opts):
        User = get_user_model()
        if opts["reset"]:
            Block.objects.all().delete(); AuditLog.objects.all().delete()
            RankingRun.objects.all().delete(); SchoolIndicators.objects.all().delete(); School.objects.all().delete()
        if School.objects.exists():
            return self.stdout.write("Schools already exist; use --reset to rebuild the demo data.")

        rng = np.random.default_rng(42)
        names = [f"{b} {s}" for b in BASES for s in SUFFIX]
        rng.shuffle(names)
        provs = list(PLACES)
        schools = []
        for i in range(min(opts["schools"], len(names))):
            prov = provs[i % len(provs)]
            districts, lat, lng = PLACES[prov]
            schools.append(School.objects.create(
                name=names[i], registration_number=f"DEMO-{i + 1:04d}",
                school_type=str(rng.choice(["government", "private", "mission"], p=[.5, .3, .2])),
                boarding_type=str(rng.choice(["day", "boarding"], p=[.6, .4])),
                province=prov, district=districts[i % len(districts)],
                latitude=lat + float(rng.uniform(-.25, .25)), longitude=lng + float(rng.uniform(-.25, .25)),
                email=f"info@demo-school-{i + 1}.example", website=f"https://demo-school-{i + 1}.example"))

        mk = lambda u, r, **kw: User.objects.create_user(username=u, password=DEMO_PASSWORD, role=r,
                                                          email=f"{u}@example.com", **kw)
        admin = User.objects.create_superuser("admin", "admin@example.com", DEMO_PASSWORD, role="super_admin")
        ministry = mk("ministry", "ministry", is_staff=True)
        mk("schooladmin", "school_admin", school=schools[0], is_staff=True)
        mk("parent", "parent")
        mk("researcher", "researcher")

        RankingConfig.objects.create(name="Default", is_active=True, updated_by=admin)

        quality = {s.pk: float(np.clip(rng.normal(58, 14), 25, 90)) for s in schools}
        trends = {s.pk: float(rng.normal(1.5, 2.5)) for s in schools}
        for year in YEARS:
            for s in schools:
                data = _indicators(rng, quality[s.pk], trends[s.pk], year - YEARS[0])
                obj = sch.submit_indicators(s, year, data, admin)
                sch.verify_indicators(obj, ministry)
            run = rk.compute_run(year, ministry)
            rk.publish_run(run, ministry)
            self.stdout.write(f"  {year}: ranked and published {run.rankings.count()} schools")

        self.stdout.write(self.style.SUCCESS(
            f"Demo ready. Ledger blocks: {Block.objects.count()}. Users: admin, ministry, schooladmin, parent, "
            f"researcher (password: {DEMO_PASSWORD}). All data is synthetic."))
