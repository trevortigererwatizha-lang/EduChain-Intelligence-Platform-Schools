"""CSV parsing, validation and writing for school and indicator data (no Django imports).

Uploads are validated completely before anything is saved. Every problem is reported with its
line number so an administrator can fix the file and upload it again.
"""
import csv
import io
import math
import re
from dataclasses import dataclass, field

from .indicators import GROUPS, INDICATOR_FIELDS, KIND_HELP, field_kind

MAX_BYTES = 5 * 1024 * 1024
MAX_ROWS = 20000
MAX_ERRORS = 200

SCHOOL_COLUMNS = ["registration_number", "name", "school_type", "boarding_type", "province", "district",
                  "latitude", "longitude", "email", "website"]
SCHOOL_REQUIRED = ["registration_number", "name", "school_type", "province", "district"]
INDICATOR_COLUMNS = ["registration_number", "year"] + INDICATOR_FIELDS

SCHOOL_TYPES = {"government", "private", "mission"}
BOARDING = {"day": "day", "day school": "day", "boarding": "boarding"}
_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


@dataclass
class ParseResult:
    kind: str
    rows: list = field(default_factory=list)
    errors: list = field(default_factory=list)      # {"line", "field", "message"}
    warnings: list = field(default_factory=list)
    total_rows: int = 0
    truncated_errors: bool = False

    @property
    def ok(self):
        return not self.errors and bool(self.rows)


def _norm_header(h):
    return re.sub(r"[\s\-]+", "_", (h or "").strip().lower())


def _decode(data):
    if isinstance(data, str):
        return data
    try:
        return data.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise ValueError("The file is not UTF-8 text. In Excel choose Save As > CSV UTF-8.")


def _err(res, line, fld, msg):
    if len(res.errors) >= MAX_ERRORS:
        res.truncated_errors = True
        return
    res.errors.append({"line": line, "field": fld, "message": msg})


def _number(raw):
    s = raw.strip().replace(",", "") if isinstance(raw, str) else raw
    v = float(s)
    if math.isnan(v) or math.isinf(v):
        raise ValueError
    return v


def parse_value(name, raw):
    """Return the cleaned value for an indicator cell or raise ValueError with a readable message."""
    if raw is None or str(raw).strip() == "":
        raise ValueError("is empty (every indicator needs a value; use 0 if none)")
    kind = field_kind(name)
    try:
        v = _number(raw)
    except ValueError:
        raise ValueError(f"'{raw}' is not a number")
    if kind == "count":
        if v < 0 or v != int(v):
            raise ValueError(f"'{raw}' must be a whole number, 0 or more")
        return int(v)
    if kind == "percent" and not 0 <= v <= 100:
        raise ValueError(f"{v:g} is outside 0 to 100")
    if kind == "positive" and v <= 0:
        raise ValueError(f"{v:g} must be greater than 0")
    if kind == "money" and v < 0:
        raise ValueError(f"{v:g} cannot be negative")
    if kind == "signed" and not -100 <= v <= 1000:
        raise ValueError(f"{v:g} is not a believable percent change")
    return v


def _reader(text, res, required):
    reader = csv.DictReader(io.StringIO(text))
    if not reader.fieldnames:
        _err(res, 1, "", "The file is empty or has no header row.")
        return None, {}
    mapping = {}
    for raw in reader.fieldnames:
        key = _norm_header(raw)
        if key in mapping.values():
            _err(res, 1, raw, f"Column '{raw}' appears twice.")
        mapping[raw] = key
    present = set(mapping.values())
    missing = [c for c in required if c not in present]
    if missing:
        _err(res, 1, "", "Missing column(s): " + ", ".join(missing) + ". Download the template to get the exact headers.")
    return reader, mapping


def _rows(reader, mapping, res):
    for line, raw in enumerate(reader, start=2):
        res.total_rows += 1
        if res.total_rows > MAX_ROWS:
            _err(res, line, "", f"More than {MAX_ROWS} rows. Split the file.")
            return
        if None in raw:  # more cells than headers
            _err(res, line, "", "This row has more cells than the header has columns.")
            continue
        row = {mapping[k]: (v or "").strip() for k, v in raw.items() if k is not None}
        if not any(row.values()):
            res.total_rows -= 1
            continue
        yield line, row


def parse_schools(data):
    res = ParseResult("schools")
    try:
        text = _decode(data)
    except ValueError as e:
        _err(res, 0, "", str(e)); return res
    if len(text.encode()) > MAX_BYTES:
        _err(res, 0, "", "File is larger than 5 MB."); return res
    reader, mapping = _reader(text, res, SCHOOL_REQUIRED)
    if reader is None or res.errors:
        return res
    unknown = sorted(set(mapping.values()) - set(SCHOOL_COLUMNS))
    if unknown:
        res.warnings.append("Ignored unknown column(s): " + ", ".join(unknown))
    seen = {}
    for line, row in _rows(reader, mapping, res):
        before = len(res.errors)
        reg = row.get("registration_number", "")
        if not reg or len(reg) > 50:
            _err(res, line, "registration_number", "is required and must be 50 characters or fewer")
        elif reg in seen:
            _err(res, line, "registration_number", f"'{reg}' already appears on line {seen[reg]}")
        else:
            seen[reg] = line
        if not row.get("name") or len(row["name"]) > 200:
            _err(res, line, "name", "is required and must be 200 characters or fewer")
        stype = row.get("school_type", "").lower()
        if stype not in SCHOOL_TYPES:
            _err(res, line, "school_type", f"'{row.get('school_type', '')}' must be one of: government, private, mission")
        boarding = BOARDING.get(row.get("boarding_type", "").lower() or "day")
        if boarding is None:
            _err(res, line, "boarding_type", f"'{row['boarding_type']}' must be day or boarding")
        for f in ("province", "district"):
            if not row.get(f) or len(row[f]) > 80:
                _err(res, line, f, "is required and must be 80 characters or fewer")
        lat = lng = None
        if row.get("latitude") or row.get("longitude"):
            try:
                lat, lng = _number(row.get("latitude", "")), _number(row.get("longitude", ""))
                if not (-90 <= lat <= 90):
                    _err(res, line, "latitude", f"{lat:g} is outside -90 to 90")
                if not (-180 <= lng <= 180):
                    _err(res, line, "longitude", f"{lng:g} is outside -180 to 180")
            except ValueError:
                _err(res, line, "latitude", "latitude and longitude must both be numbers or both be blank")
        email = row.get("email", "")
        if email and not _EMAIL.match(email):
            _err(res, line, "email", f"'{email}' is not a valid email address")
        site = row.get("website", "")
        if site and not re.match(r"^https?://\S+$", site, re.I):
            _err(res, line, "website", "must start with http:// or https://")
        if len(res.errors) == before:
            res.rows.append({"_line": line, "registration_number": reg, "name": row["name"], "school_type": stype,
                             "boarding_type": boarding, "province": row["province"], "district": row["district"],
                             "latitude": lat, "longitude": lng, "email": email, "website": site})
    if not res.rows and not res.errors:
        _err(res, 1, "", "The file has a header but no data rows.")
    return res


def parse_indicators(data):
    res = ParseResult("indicators")
    try:
        text = _decode(data)
    except ValueError as e:
        _err(res, 0, "", str(e)); return res
    if len(text.encode()) > MAX_BYTES:
        _err(res, 0, "", "File is larger than 5 MB."); return res
    reader, mapping = _reader(text, res, INDICATOR_COLUMNS)
    if reader is None or res.errors:
        return res
    unknown = sorted(set(mapping.values()) - set(INDICATOR_COLUMNS))
    if unknown:
        res.warnings.append("Ignored unknown column(s): " + ", ".join(unknown))
    seen = {}
    for line, row in _rows(reader, mapping, res):
        before = len(res.errors)
        reg = row.get("registration_number", "")
        if not reg:
            _err(res, line, "registration_number", "is required")
        year = None
        try:
            year = int(_number(row.get("year", "")))
            if not 1990 <= year <= 2100:
                raise ValueError
        except ValueError:
            _err(res, line, "year", f"'{row.get('year', '')}' is not a year between 1990 and 2100")
        if reg and year:
            if (reg, year) in seen:
                _err(res, line, "registration_number", f"'{reg}' for {year} already appears on line {seen[(reg, year)]}")
            else:
                seen[(reg, year)] = line
        values = {}
        for name in INDICATOR_FIELDS:
            try:
                values[name] = parse_value(name, row.get(name))
            except ValueError as e:
                _err(res, line, name, str(e))
        if len(res.errors) == before:
            res.rows.append({"_line": line, "registration_number": reg, "year": year, **values})
    if not res.rows and not res.errors:
        _err(res, 1, "", "The file has a header but no data rows.")
    return res


# ----------------------------------------------------------------------------- writing
def safe_cell(v):
    """Stop spreadsheet formula injection: text that starts with = + - @ is prefixed with a quote."""
    if isinstance(v, str) and v[:1] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + v
    return v


def write_csv(header, rows):
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\r\n")
    w.writerow(header)
    for r in rows:
        w.writerow([safe_cell("" if v is None else v) for v in r])
    return ("﻿" + buf.getvalue()).encode("utf-8")  # BOM so Excel opens it as UTF-8


def data_dictionary():
    """Rows for the on-screen guide: column, group, accepted values."""
    out = [{"group": "School profile", "column": "registration_number", "help": "unique id, up to 50 characters"},
           {"group": "School profile", "column": "name", "help": "text, up to 200 characters"},
           {"group": "School profile", "column": "school_type", "help": "government, private or mission"},
           {"group": "School profile", "column": "boarding_type", "help": "day or boarding (blank means day)"},
           {"group": "School profile", "column": "province", "help": "text"},
           {"group": "School profile", "column": "district", "help": "text"},
           {"group": "School profile", "column": "latitude / longitude", "help": "decimal degrees; both or neither"},
           {"group": "School profile", "column": "email / website", "help": "optional; website starts with http(s)://"}]
    for g, fields in GROUPS.items():
        for f in fields:
            out.append({"group": g, "column": f, "help": KIND_HELP[field_kind(f)]})
    return out
