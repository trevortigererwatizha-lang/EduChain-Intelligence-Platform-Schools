from django.urls import path

from . import views

app_name = "schools"

urlpatterns = [
    path("", views.hub, name="hub"),
    path("upload/", views.upload, name="upload"),
    path("confirm/<int:pk>/", views.confirm, name="confirm"),
    path("discard/<int:pk>/", views.discard, name="discard"),
    path("template/<str:kind>.csv", views.template_csv, name="template"),
    path("export/<str:kind>.csv", views.export_csv, name="export"),
]
