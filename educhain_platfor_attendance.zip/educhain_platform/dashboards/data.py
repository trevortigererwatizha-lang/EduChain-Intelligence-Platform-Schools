"""Database-backed data shaping for the dashboard pages."""
import json
from collections import Counter, defaultdict

import numpy as np
from django.core.cache import cache

from analytics import services as an
from analytics import trends
from blockchain import service as chain
from blockchain.models import Block
from rankings import insights, scoring
from rankings.models import RankingRun

CORE = an.CORE
LABELS = insights.LABELS
SHORT = {"academic": "Academic", "enrollment": "Enrollment", "teacher": "Teaching", "infrastructure": "Facilities",
         "finance": "Finance", "sports": "Sports", "innovation": "Innovation", "welfare": "Welfare",
         "community": "Community"}
CAT_META = [{"key": c, "label": SHORT[c]} for c in CORE]
PUBLISHED = RankingRun.Status.PUBLISHED


def published_runs():
    return list(RankingRun.objects.filter(status=PUBLISHED).order_by("year"))


def pick_run(year_param):
    """(run or None, years newest-first). A bad or unknown ?year= falls back to the latest ranking."""
    runs = published_runs()
    years = sorted({r.year for r in runs}, reverse=True)
    run = runs[-1] if runs else None
    if year_param and str(year_param).isdigit():
        run = next((r for r in runs if r.year == int(year_param)), run)
    return run, years


def previous_run(run):
    return RankingRun.objects.filter(status=PUBLISHED, year__lt=run.year).order_by("-year").first()


def vec(r):
    return [r.scores.get(c, 0.0) for c in CORE]


def ledger_status():
    """Chain verification, cached briefly because it re-hashes every block."""
    st = cache.get("ledger-status")
    if st is None:
        st = chain.verify_chain()
        cache.set("ledger-status", st, 30)
    return st


# ----------------------------------------------------------------------------- overview
def overview(run):
    rows = list(run.rankings.select_related("school"))
    summary = an.national_summary(run)
    prev = previous_run(run)
    prev_avg = None
    if prev:
        vals = [r.overall for r in prev.rankings.all()]
        prev_avg = float(np.mean(vals)) if vals else None
    avg = summary["national_average"]
    return {
        "summary": summary, "heatmap": an.heatmap(run), "points": an.map_points(run),
        "avg_change": round(avg - prev_avg, 2) if (avg is not None and prev_avg is not None) else None,
        "province_count": len({r.school.province for r in rows}),
        "top_tier_count": sum(1 for r in rows if r.tier in ("Platinum", "Gold")),
        "top5": rows[:5],  # run.rankings is already ordered by national rank
        "ledger": ledger_status(), "block_count": Block.objects.count(),
        "latest_cert": next((r for r in rows if r.national_rank == 1), None),
    }


# ----------------------------------------------------------------------------- provinces
def province_stats(run):
    by = defaultdict(list)
    for r in run.rankings.select_related("school"):
        by[r.school.province].append(r)
    out = []
    for name, items in by.items():
        items.sort(key=lambda r: (r.national_rank, r.school.name))
        out.append({
            "name": name, "schools": len(items), "districts": len({r.school.district for r in items}),
            "avg": round(float(np.mean([r.overall for r in items])), 2), "best": items[0],
            "tiers": dict(Counter(r.tier for r in items)),
            "cats": {c: round(float(np.mean([r.scores.get(c, 0) for r in items])), 1) for c in CORE},
        })
    out.sort(key=lambda p: -p["avg"])
    for i, p in enumerate(out, 1):
        p["rank"] = i
    return out


def province_detail(run, name):
    rows = [r for r in run.rankings.select_related("school") if r.school.province == name]
    if not rows:
        return None
    rows.sort(key=lambda r: (r.provincial_rank, r.school.name))
    by = defaultdict(list)
    for r in rows:
        by[r.school.district].append(r)
    districts = sorted(
        ({"name": d, "schools": len(v), "avg": round(float(np.mean([r.overall for r in v])), 2),
          "best": min(v, key=lambda r: r.district_rank)} for d, v in by.items()), key=lambda d: -d["avg"])
    nat = an.national_median(run)
    cats = {c: round(float(np.mean([r.scores.get(c, 0) for r in rows])), 1) for c in CORE}
    return {"rows": rows, "districts": districts, "tiers": dict(Counter(r.tier for r in rows)),
            "avg": round(float(np.mean([r.overall for r in rows])), 2), "cats": cats,
            "national": {c: round(nat.get(c, 0), 1) for c in CORE}}


# ----------------------------------------------------------------------------- trends
def trends_data():
    runs = published_runs()
    series, cat_series, tiers_by_year = [], {c: [] for c in CORE}, []
    ranks, tiers, names = {}, {}, {}
    for run in runs:
        rows = list(run.rankings.select_related("school"))
        if not rows:
            continue
        vals = [r.overall for r in rows]
        series.append({"year": run.year, "schools": len(rows), "avg": round(float(np.mean(vals)), 2),
                       "median": round(float(np.median(vals)), 2), "top": round(max(vals), 2)})
        for c in CORE:
            cat_series[c].append(round(float(np.mean([r.scores.get(c, 0) for r in rows])), 2))
        counts = Counter(r.tier for r in rows)
        tiers_by_year.append({"year": run.year, **{t: counts.get(t, 0) for t in trends.TIER_ORDER[::-1]}})
        ranks[run.year] = {r.school_id: r.national_rank for r in rows}
        tiers[run.year] = {r.school_id: r.tier for r in rows}
        for r in rows:
            names[r.school_id] = r.school
    out = {"series": series, "cat_series": cat_series, "tiers_by_year": tiers_by_year, "years": [s["year"] for s in series],
           "movers": None, "transitions": None}
    if len(series) >= 2:
        y0, y1 = series[-2]["year"], series[-1]["year"]
        mv = trends.movers(ranks[y0], ranks[y1], 8)
        pack = lambda lst: [{"school": names[sid], "delta": d, "from": ranks[y0][sid], "to": ranks[y1][sid]} for sid, d in lst]
        out["movers"] = {"from": y0, "to": y1, "risers": pack(mv["risers"]), "fallers": pack(mv["fallers"])}
        out["transitions"] = {"from": y0, "to": y1, **trends.tier_transitions(tiers[y0], tiers[y1])}
        t = out["transitions"]
        t["rows"] = [{"from": a, "cells": [t["matrix"][a][b] for b in t["order"]]} for a in t["order"][::-1]]
    return out


# ----------------------------------------------------------------------------- leaderboards, finder, risk
def leaderboard(run, category, province="", school_type="", limit=25):
    rows = [r for r in run.rankings.select_related("school")
            if (not province or r.school.province == province) and (not school_type or r.school.school_type == school_type)]
    rows.sort(key=lambda r: (-r.scores.get(category, 0), r.national_rank))
    return rows[:limit]


def finder_payload(run):
    return [{"id": r.school_id, "name": r.school.name, "province": r.school.province, "district": r.school.district,
             "type": r.school.school_type, "boarding": r.school.boarding_type, "tier": r.tier,
             "overall": round(r.overall, 2), "rank": r.national_rank,
             "scores": {c: round(r.scores.get(c, 0), 1) for c in CORE}} for r in run.rankings.select_related("school")]


def similar_schools(run, ranking, k=5):
    others = {r.school_id: vec(r) for r in run.rankings.all() if r.school_id != ranking.school_id}
    if not others:
        return []
    near = trends.nearest(vec(ranking), others, k)
    by_id = {r.school_id: r for r in run.rankings.select_related("school").filter(school_id__in=[n[0] for n in near])}
    return [by_id[sid] for sid, _ in near if sid in by_id]


def early_warning(run):
    prev = previous_run(run)
    prev_by = {r.school_id: r for r in prev.rankings.all()} if prev else {}
    out = []
    for r in run.rankings.select_related("school"):
        p = prev_by.get(r.school_id)
        risks = insights.risk_factors(r.scores, p.scores if p else None)
        drop = (r.national_rank - p.national_rank) if p else 0       # positive = fell down the table
        tier_drop = bool(p) and trends.TIER_ORDER.index(r.tier) < trends.TIER_ORDER.index(p.tier)
        severity = sum(2 if x["level"] == "high" else 1 for x in risks) + (2 if drop >= 5 else 0) + (2 if tier_drop else 0)
        if severity:
            out.append({"r": r, "risks": risks, "drop": drop if drop > 0 else 0, "tier_drop": tier_drop,
                        "prev_tier": p.tier if p else None, "severity": severity})
    out.sort(key=lambda x: (-x["severity"], x["r"].national_rank))
    return out


# ----------------------------------------------------------------------------- ledger
def describe_block(b):
    p, t = b.payload or {}, b.record_type
    if t == "ranking":
        return f"{p.get('school_name', 'School')}, {p.get('year', '')}: rank {p.get('national_rank', '?')}, {p.get('tier', '')}"
    if t == "validation":
        return f"Data verified for {p.get('school', '?')} ({p.get('year', '')}) by {p.get('verified_by', '?')}"
    if t == "methodology":
        return f"Methodology for the {p.get('year', '')} ranking"
    if t == "config_change":
        return f"Ranking weights changed by {p.get('changed_by', '?')}"
    return "Genesis block" if t == "genesis" else t.replace("_", " ").capitalize()


def pretty(b):
    return json.dumps(b.payload, indent=2, sort_keys=True)
