/* EduChain front-end helpers. No framework; every storage call is guarded because it can throw or come back empty. */
(function () {
  'use strict';
  var EC = (window.EC = {});
  var root = document.documentElement;
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) { /* storage unavailable */ } }
  };
  EC.store = store;

  /* ---------- theme ---------- */
  function currentTheme() { return root.getAttribute('data-theme') === 'dark' ? 'dark' : 'light'; }
  function paintThemeButtons() {
    document.querySelectorAll('[data-theme-toggle]').forEach(function (b) {
      var dark = currentTheme() === 'dark';
      b.setAttribute('aria-pressed', dark ? 'true' : 'false');
      b.setAttribute('aria-label', dark ? 'Switch to light theme' : 'Switch to dark theme');
      b.innerHTML = '<svg class="icon"><use href="#i-' + (dark ? 'sun' : 'moon') + '"/></svg>';
    });
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-theme-toggle]');
    if (!b) return;
    var next = currentTheme() === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    store.set('ec-theme', next);
    paintThemeButtons();
    document.dispatchEvent(new CustomEvent('themechange'));
  });
  paintThemeButtons();

  /* ---------- colours and charts ---------- */
  EC.css = function (name) { return getComputedStyle(root).getPropertyValue(name).trim(); };
  EC.tierColor = function (t) { return EC.css('--' + String(t).toLowerCase()); };
  EC.tiers = ['Platinum', 'Gold', 'Silver', 'Bronze', 'Emerging'];
  EC.grid = function () { return { color: EC.css('--line-2'), drawTicks: false }; };

  var charts = [];
  function chartDefaults() {
    if (!window.Chart) return;
    Chart.defaults.font.family = getComputedStyle(document.body).fontFamily;
    Chart.defaults.font.size = 12.5;
    Chart.defaults.color = EC.css('--muted');
    Chart.defaults.borderColor = EC.css('--line');
    Chart.defaults.plugins.legend.labels.usePointStyle = true;
    Chart.defaults.plugins.legend.labels.boxWidth = 8;
  }
  /* EC.chart('canvas-id', function (EC) { return chartJsConfig; }) rebuilds itself when the theme changes. */
  EC.chart = function (id, factory) {
    var el = document.getElementById(id);
    if (!el || !window.Chart) return null;
    var entry = { inst: null };
    entry.build = function () {
      if (entry.inst) entry.inst.destroy();
      chartDefaults();
      var cfg = factory(EC);
      cfg.options = cfg.options || {};
      if (cfg.options.maintainAspectRatio === undefined) cfg.options.maintainAspectRatio = false;
      entry.inst = new Chart(el, cfg);
    };
    charts.push(entry);
    entry.build();
    return entry;
  };
  document.addEventListener('themechange', function () { charts.forEach(function (c) { c.build(); }); });

  /* ---------- saved schools (this browser only) ---------- */
  function readSaved() {
    try { var a = JSON.parse(store.get('ec-saved', '[]')); return Array.isArray(a) ? a.map(Number) : []; } catch (e) { return []; }
  }
  EC.saved = {
    all: readSaved,
    has: function (id) { return readSaved().indexOf(Number(id)) !== -1; },
    toggle: function (id) {
      id = Number(id);
      var a = readSaved(), i = a.indexOf(id);
      if (i === -1) a.push(id); else a.splice(i, 1);
      store.set('ec-saved', JSON.stringify(a));
      paintSaved();
      document.dispatchEvent(new CustomEvent('savedchange'));
      return i === -1;
    }
  };
  function paintSaved() {
    var a = readSaved();
    document.querySelectorAll('[data-save]').forEach(function (b) {
      var on = a.indexOf(Number(b.getAttribute('data-save'))) !== -1;
      b.setAttribute('aria-pressed', on ? 'true' : 'false');
      b.setAttribute('title', on ? 'Remove from saved schools' : 'Save this school');
    });
    document.querySelectorAll('[data-saved-count]').forEach(function (n) { n.textContent = a.length; n.hidden = a.length === 0; });
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-save]');
    if (!b) return;
    e.preventDefault(); e.stopPropagation();
    EC.saved.toggle(b.getAttribute('data-save'));
  });
  EC.paintSaved = paintSaved;
  paintSaved();

  /* ---------- tabs ---------- */
  document.querySelectorAll('[data-tabs]').forEach(function (wrap) {
    var tabs = wrap.querySelectorAll('[role=tab]');
    function show(id) {
      tabs.forEach(function (t) {
        var on = t.getAttribute('aria-controls') === id;
        t.setAttribute('aria-selected', on ? 'true' : 'false');
        var p = document.getElementById(t.getAttribute('aria-controls'));
        if (p) p.hidden = !on;
      });
      document.dispatchEvent(new CustomEvent('tabshown', { detail: id }));
    }
    tabs.forEach(function (t) { t.addEventListener('click', function () { show(t.getAttribute('aria-controls')); }); });
    var first = Array.prototype.filter.call(tabs, function (t) { return t.getAttribute('aria-selected') === 'true'; })[0] || tabs[0];
    if (first) show(first.getAttribute('aria-controls'));
  });

  /* ---------- sortable tables ---------- */
  document.querySelectorAll('table[data-sortable]').forEach(function (tbl) {
    var heads = tbl.querySelectorAll('th[data-sort]');
    heads.forEach(function (th, _i) {
      th.addEventListener('click', function () {
        var idx = Array.prototype.indexOf.call(th.parentNode.children, th);
        var asc = th.getAttribute('aria-sort') !== 'ascending';
        heads.forEach(function (h) { h.removeAttribute('aria-sort'); });
        th.setAttribute('aria-sort', asc ? 'ascending' : 'descending');
        var num = th.getAttribute('data-sort') === 'num';
        var body = tbl.tBodies[0];
        var rows = Array.prototype.slice.call(body.rows);
        function val(r) {
          var c = r.cells[idx], v = c.getAttribute('data-v');
          if (v === null) v = c.textContent.trim();
          return num ? (parseFloat(v) || 0) : v.toLowerCase();
        }
        rows.sort(function (a, b) { var x = val(a), y = val(b); return (x < y ? -1 : x > y ? 1 : 0) * (asc ? 1 : -1); });
        rows.forEach(function (r) { body.appendChild(r); });
      });
    });
  });

  /* ---------- small behaviours ---------- */
  var menu = document.querySelector('.menu-btn');
  if (menu) menu.addEventListener('click', function () { document.body.classList.toggle('nav-open'); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') document.body.classList.remove('nav-open'); });
  document.addEventListener('click', function (e) {
    if (document.body.classList.contains('nav-open') && !e.target.closest('.rail') && !e.target.closest('.menu-btn')) {
      document.body.classList.remove('nav-open');
    }
  });

  document.querySelectorAll('select[data-year-switch]').forEach(function (s) {
    s.addEventListener('change', function () {
      var u = new URL(window.location.href);
      u.searchParams.set('year', s.value);
      u.searchParams.delete('page');
      window.location.href = u.toString();
    });
  });

  window.requestAnimationFrame(function () {
    document.querySelectorAll('.bar > i[data-w]').forEach(function (b) { b.style.width = b.getAttribute('data-w') + '%'; });
  });

  /* remember the ranking view (table, cards, compact) */
  document.querySelectorAll('[data-view-link]').forEach(function (a) {
    a.addEventListener('click', function () { store.set('ec-view', a.getAttribute('data-view-link')); });
  });
  var vp = document.querySelector('[data-view-default]');
  if (vp) {
    var want = store.get('ec-view', ''), u = new URL(window.location.href);
    if (want && !u.searchParams.has('view') && want !== vp.getAttribute('data-view-default') &&
        ['table', 'cards', 'compact'].indexOf(want) !== -1) {
      u.searchParams.set('view', want);
      window.location.replace(u.toString());
    }
  }

  /* file drop zone on the data hub */
  document.querySelectorAll('.dz').forEach(function (dz) {
    var input = dz.querySelector('input[type=file]'), label = dz.querySelector('[data-dz-label]');
    if (!input) return;
    input.addEventListener('change', function () { if (label && input.files[0]) label.textContent = input.files[0].name; });
    ['dragenter', 'dragover'].forEach(function (n) { dz.addEventListener(n, function (e) { e.preventDefault(); dz.classList.add('drag'); }); });
    ['dragleave', 'drop'].forEach(function (n) { dz.addEventListener(n, function (e) { e.preventDefault(); dz.classList.remove('drag'); }); });
    dz.addEventListener('drop', function (e) { if (e.dataTransfer.files.length) { input.files = e.dataTransfer.files; input.dispatchEvent(new Event('change')); } });
  });
})();
