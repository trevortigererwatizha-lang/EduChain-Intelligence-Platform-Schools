from django.urls import path

from . import views

app_name = "dashboards"

urlpatterns = [
    path("", views.overview, name="overview"),
    path("rankings/", views.rankings, name="rankings"),
    path("rankings/export.csv", views.rankings_export, name="rankings_export"),
    path("schools/<int:pk>/", views.school_detail, name="school"),
    path("compare/", views.compare, name="compare"),
    path("provinces/", views.provinces, name="provinces"),
    path("provinces/<str:name>/", views.province_detail, name="province"),
    path("trends/", views.trends, name="trends"),
    path("leaderboards/", views.leaderboards, name="leaderboards"),
    path("find/", views.finder, name="finder"),
    path("find/data.json", views.explore_json, name="explore_json"),
    path("early-warning/", views.early_warning, name="early_warning"),
    path("ledger/", views.ledger, name="ledger"),
    path("methodology/", views.methodology, name="methodology"),
    path("verify/", views.verify, name="verify"),
    path("verify/<str:cert_hash>/", views.verify, name="verify_hash"),
]
