import json

from django.core.paginator import Paginator
from django.http import Http404, HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, render

from analytics import services as an
from blockchain.models import Block
from rankings import scoring, services as rk
from rankings.models import RankingRun, SchoolRanking
from schools import csvio
from schools.models import School
from schools.views import staff_only

from . import data

TIER_NAMES = [t for t, _ in scoring.TIERS] + ["Emerging"]
VIEWS = ("table", "cards", "compact")


def _start(request, nav):
    run, years = data.pick_run(request.GET.get("year"))
    return run, years, {"nav": nav, "run": run, "years": years}


def _empty(request, nav, years):
    return render(request, "dashboards/empty.html", {"nav": nav, "years": years})


def _qs(request, drop=()):
    q = request.GET.copy()
    for k in drop:
        q.pop(k, None)
    return q.urlencode()


# ----------------------------------------------------------------------------- overview
def overview(request):
    run, years, ctx = _start(request, "overview")
    if not run:
        return _empty(request, "overview", years)
    ctx.update(data.overview(run))
    return render(request, "dashboards/overview.html", ctx)


# ----------------------------------------------------------------------------- rankings
def _filtered(run, g):
    rows = list(run.rankings.select_related("school"))
    for param, test in (("province", lambda r, v: r.school.province == v),
                        ("district", lambda r, v: r.school.district == v),
                        ("type", lambda r, v: r.school.school_type == v),
                        ("boarding", lambda r, v: r.school.boarding_type == v),
                        ("tier", lambda r, v: r.tier == v)):
        if g.get(param):
            rows = [r for r in rows if test(r, g[param])]
    if g.get("q"):
        needle = g["q"].strip().lower()
        rows = [r for r in rows if needle in r.school.name.lower()]
    sort = g.get("sort", "")
    level = g.get("level", "national")
    if sort in data.CORE:
        rows.sort(key=lambda r: (-r.scores.get(sort, 0), r.national_rank))
    elif sort == "overall" or level == "national":
        rows.sort(key=lambda r: (r.national_rank, r.school.name))
    elif level == "province":
        rows.sort(key=lambda r: (r.school.province, r.provincial_rank, r.school.name))
    else:
        rows.sort(key=lambda r: (r.school.province, r.school.district, r.district_rank, r.school.name))
    return rows


def rankings(request):
    run, years, ctx = _start(request, "rankings")
    if not run:
        return _empty(request, "rankings", years)
    g = request.GET
    view = g.get("view") if g.get("view") in VIEWS else "table"
    rows = _filtered(run, g)
    page = Paginator(rows, {"table": 25, "cards": 24, "compact": 60}[view]).get_page(g.get("page"))
    attr = {"province": "provincial_rank", "district": "district_rank"}.get(g.get("level"), "national_rank")
    for r in page:
        r.shown_rank = getattr(r, attr)
    base = list(run.rankings.select_related("school"))
    districts = sorted({r.school.district for r in base if not g.get("province") or r.school.province == g["province"]})
    sort = g.get("sort", "")
    ctx.update({
        "page": page, "view": view, "total": len(rows), "filters": g,
        "provinces": sorted({r.school.province for r in base}), "districts": districts, "tiers": TIER_NAMES,
        "types": School.SchoolType.choices, "boardings": School.Boarding.choices, "cats": data.CAT_META,
        "focus": sort if sort in data.CORE else "", "focus_label": data.SHORT.get(sort, ""),
        "qs_page": _qs(request, ("page",)), "qs_view": _qs(request, ("page", "view")),
        "export_qs": _qs(request, ("page", "view")),
    })
    return render(request, "dashboards/rankings.html", ctx)


def rankings_export(request):
    """Public CSV of the (filtered) published rankings."""
    run, _ = data.pick_run(request.GET.get("year"))
    if not run:
        raise Http404("No published ranking yet.")
    rows = _filtered(run, request.GET)
    header = (["year", "national_rank", "provincial_rank", "district_rank", "school", "province", "district",
               "school_type", "tier", "overall"] + data.CORE + ["certificate_hash"])
    body = [[run.year, r.national_rank, r.provincial_rank, r.district_rank, r.school.name, r.school.province,
             r.school.district, r.school.school_type, r.tier, round(r.overall, 2)] +
            [round(r.scores.get(c, 0), 1) for c in data.CORE] + [r.certificate_hash] for r in rows]
    resp = HttpResponse(csvio.write_csv(header, body), content_type="text/csv; charset=utf-8")
    resp["Content-Disposition"] = f'attachment; filename="educhain_rankings_{run.year}.csv"'
    return resp


# ----------------------------------------------------------------------------- school
def school_detail(request, pk):
    school = get_object_or_404(School, pk=pk, is_active=True)
    run, years, ctx = _start(request, "rankings")
    if not run:
        return _empty(request, "rankings", years)
    r = run.rankings.filter(school=school).first()
    if not r:
        raise Http404("This school is not ranked for the selected year.")
    median = an.national_median(run)
    bars = [{"key": c["key"], "label": c["label"], "score": round(r.scores.get(c["key"], 0), 1),
             "median": round(median.get(c["key"], 0), 1),
             "diff": round(r.scores.get(c["key"], 0) - median.get(c["key"], 0), 1)} for c in data.CAT_META]
    ordered = sorted(bars, key=lambda b: -b["diff"])
    history = list(SchoolRanking.objects.filter(school=school, run__status=RankingRun.Status.PUBLISHED)
                   .select_related("run").order_by("run__year"))
    peers = [x for x in run.rankings.select_related("school").filter(school__district=school.district)
             if x.school_id != school.pk][:5]
    ctx.update({
        "school": school, "r": r, "bars": bars, "strengths": [b for b in ordered[:2] if b["diff"] > 0],
        "gaps": [b for b in ordered[::-1][:2] if b["diff"] < 0], "median": median,
        "history": [{"year": h.run.year, "overall": round(h.overall, 2), "rank": h.national_rank, "tier": h.tier,
                     "prov": h.provincial_rank, "dist": h.district_rank} for h in history],
        "forecast": an.predict_school(school), "insight": an.school_insight(school, run.year),
        "similar": data.similar_schools(run, r), "peers": peers,
        "categories": data.CAT_META,
    })
    return render(request, "dashboards/school.html", ctx)


# ----------------------------------------------------------------------------- compare
def compare(request):
    run, years, ctx = _start(request, "compare")
    if not run:
        return _empty(request, "compare", years)
    ids = [int(i) for i in request.GET.get("ids", "").split(",") if i.strip().isdigit()][:4]
    by_id = {r.school_id: r for r in run.rankings.filter(school_id__in=ids).select_related("school")}
    picked = [by_id[i] for i in ids if i in by_id]
    matrix = []
    for c in data.CAT_META:
        vals = [r.scores.get(c["key"], 0) for r in picked]
        best = max(vals) if vals else None
        matrix.append({"label": c["label"], "cells": [{"v": round(v, 1), "best": len(picked) > 1 and v == best} for v in vals]})
    ctx.update({
        "picked": picked, "ids": ",".join(str(r.school_id) for r in picked), "matrix": matrix,
        "everyone": run.rankings.select_related("school").order_by("school__name"), "categories": data.CAT_META,
        "chart": [{"label": r.school.name, "data": [round(r.scores.get(c["key"], 0), 1) for c in data.CAT_META]} for r in picked],
        "selected": [r.school_id for r in picked],
    })
    return render(request, "dashboards/compare.html", ctx)


# ----------------------------------------------------------------------------- provinces
def provinces(request):
    run, years, ctx = _start(request, "provinces")
    if not run:
        return _empty(request, "provinces", years)
    stats = data.province_stats(run)
    ctx.update({"stats": stats, "stats_json": [{"name": p["name"], "cats": p["cats"]} for p in stats],
                "cats": data.CAT_META, "tiers": TIER_NAMES})
    return render(request, "dashboards/provinces.html", ctx)


def province_detail(request, name):
    run, years, ctx = _start(request, "provinces")
    if not run:
        return _empty(request, "provinces", years)
    d = data.province_detail(run, name)
    if not d:
        raise Http404("No ranked schools in this province for the selected year.")
    ctx.update({"province": name, "d": d, "cats": data.CAT_META, "tiers": TIER_NAMES})
    return render(request, "dashboards/province.html", ctx)


# ----------------------------------------------------------------------------- trends, leaderboards
def trends(request):
    run, years, ctx = _start(request, "trends")
    if not run:
        return _empty(request, "trends", years)
    t = data.trends_data()
    t_json = {k: t[k] for k in ("series", "cat_series", "tiers_by_year", "years")}  # model objects stay out of JSON
    ctx.update({"t": t, "t_json": t_json, "cats": data.CAT_META, "tiers": TIER_NAMES})
    return render(request, "dashboards/trends.html", ctx)


def leaderboards(request):
    run, years, ctx = _start(request, "leaderboards")
    if not run:
        return _empty(request, "leaderboards", years)
    g = request.GET
    cat = g.get("cat") if g.get("cat") in data.CORE else "academic"
    rows = data.leaderboard(run, cat, g.get("province", ""), g.get("type", ""))
    base = run.rankings.select_related("school")
    ctx.update({"cat": cat, "cat_label": data.SHORT[cat], "rows": rows, "cats": data.CAT_META, "filters": g,
                "provinces": sorted({r.school.province for r in base}), "types": School.SchoolType.choices,
                "qs_cat": _qs(request, ("cat",))})
    return render(request, "dashboards/leaderboards.html", ctx)


# ----------------------------------------------------------------------------- finder
def finder(request):
    run, years, ctx = _start(request, "finder")
    if not run:
        return _empty(request, "finder", years)
    ctx.update({"cats": data.CAT_META, "weights": {c: scoring.DEFAULT_WEIGHTS.get(c, 0) for c in data.CORE},
                "types": School.SchoolType.choices, "boardings": School.Boarding.choices})
    return render(request, "dashboards/finder.html", ctx)


def explore_json(request):
    run, _ = data.pick_run(request.GET.get("year"))
    if not run:
        return JsonResponse({"year": None, "schools": []})
    resp = JsonResponse({"year": run.year, "schools": data.finder_payload(run)})
    resp["Cache-Control"] = "public, max-age=60"
    return resp


# ----------------------------------------------------------------------------- early warning (staff)
@staff_only
def early_warning(request):
    run, years, ctx = _start(request, "early")
    if not run:
        return _empty(request, "early", years)
    items = data.early_warning(run)
    ctx.update({"items": items[:150], "total": len(items),
                "high": sum(1 for i in items if i["severity"] >= 4), "tier_drops": sum(1 for i in items if i["tier_drop"])})
    return render(request, "dashboards/early_warning.html", ctx)


# ----------------------------------------------------------------------------- ledger, methodology, verify
def ledger(request):
    run, years, ctx = _start(request, "ledger")
    g = request.GET
    qs = Block.objects.order_by("-index")
    if g.get("type"):
        qs = qs.filter(record_type=g["type"])
    q = g.get("q", "").strip()
    if q.isdigit():
        qs = qs.filter(index=int(q))
    elif q:
        qs = qs.filter(hash__startswith=q.lower())
    page = Paginator(qs, 20).get_page(g.get("page"))
    for b in page:
        b.summary, b.pretty = data.describe_block(b), data.pretty(b)
    ctx.update({"page": page, "status": data.ledger_status(), "filters": g, "qs_page": _qs(request, ("page",)),
                "types": list(Block.objects.order_by().values_list("record_type", flat=True).distinct()),
                "total": Block.objects.count()})
    return render(request, "dashboards/ledger.html", ctx)


def methodology(request):
    run, years, ctx = _start(request, "method")
    doc = scoring.methodology_document(rk.active_weights())
    weights = sorted(({"key": k, "label": data.SHORT.get(k, k.title()), "w": v, "pct": round(v * 100, 1),
                       "inputs": doc["category_inputs"].get(k, "")} for k, v in doc["weights"].items()),
                     key=lambda x: -x["w"])
    ctx.update({"doc": doc, "weights": weights, "doc_hash": scoring.document_hash(doc),
                "tier_rules": [{"tier": t, "rule": rule} for t, rule in doc["tiers"].items()]})
    return render(request, "dashboards/methodology.html", ctx)


def verify(request, cert_hash=None):
    cert_hash = (cert_hash or request.GET.get("hash", "")).strip()
    run, years = data.pick_run(None)
    ctx = {"nav": "verify", "run": None, "years": [], "hash": cert_hash}
    if cert_hash:
        r = SchoolRanking.objects.filter(certificate_hash=cert_hash, run__status=RankingRun.Status.PUBLISHED) \
            .select_related("school", "run").first()
        ctx.update({"r": r, "result": rk.verify_ranking(r) if r else None, "searched": True})
    return render(request, "dashboards/verify.html", ctx)
