from celery import shared_task

from analytics.services import published_run

from .services import build_report


@shared_task(name="reports.tasks.scheduled_report")
def scheduled_report(period="monthly"):
    """Run by Celery beat (monthly / quarterly / yearly): national report in every format."""
    run = published_run()
    if not run:
        return "no published ranking yet"
    made = [build_report(run, "national", fmt, period=period).pk for fmt in ("pdf", "xlsx", "csv")]
    return f"created reports {made}"
