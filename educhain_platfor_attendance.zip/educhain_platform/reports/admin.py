from django.contrib import admin, messages

from analytics.services import published_run

from .models import Report
from .services import build_report


@admin.register(Report)
class ReportAdmin(admin.ModelAdmin):
    list_display = ("title", "kind", "fmt", "year", "period", "created_at")
    list_filter = ("kind", "fmt", "period", "year")
    actions = ["generate_national_pdf"]

    @admin.action(description="Generate a national PDF report from the latest published ranking")
    def generate_national_pdf(self, request, queryset):
        run = published_run()
        if not run:
            return self.message_user(request, "No published ranking yet.", messages.WARNING)
        build_report(run, "national", "pdf", user=request.user)
        self.message_user(request, "Report generated.")
