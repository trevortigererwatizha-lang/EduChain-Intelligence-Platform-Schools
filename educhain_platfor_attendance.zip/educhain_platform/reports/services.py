from django.core.files.base import ContentFile
from django.utils import timezone

from analytics.services import published_run

from . import generators
from .models import Report

CONTENT_TYPES = {"csv": "text/csv", "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                 "pdf": "application/pdf"}


def ranking_rows(run, level="national", province=None, district=None):
    qs = run.rankings.select_related("school")
    if province:
        qs = qs.filter(school__province__iexact=province)
    if district:
        qs = qs.filter(school__district__iexact=district)
    order = {"provincial": "provincial_rank", "district": "district_rank"}.get(level, "national_rank")
    return [{"national_rank": r.national_rank, "provincial_rank": r.provincial_rank, "district_rank": r.district_rank,
             "school": r.school.name, "province": r.school.province, "district": r.school.district, "tier": r.tier,
             "overall": round(r.overall, 2), "academic": round(r.scores.get("academic", 0), 1),
             "teacher": round(r.scores.get("teacher", 0), 1), "sports": round(r.scores.get("sports", 0), 1),
             "certificate_hash": r.certificate_hash} for r in qs.order_by(order, "school__name")]


def render(rows, fmt, title, subtitle=""):
    if fmt == "csv":
        return generators.to_csv(rows)
    if fmt == "xlsx":
        return generators.to_xlsx(rows, title)
    if fmt == "pdf":
        return generators.to_pdf(rows, title, subtitle)
    raise ValueError("fmt must be csv, xlsx or pdf")


def build_report(run, kind="national", fmt="pdf", period="manual", user=None, province=None, district=None):
    level = {"provincial": "provincial", "district": "district"}.get(kind, "national")
    rows = ranking_rows(run, level, province, district)
    title = f"{kind.title()} school rankings {run.year}" + (f" - {province}" if province else "")
    data = render(rows, fmt, title, f"Methodology hash: {run.methodology_hash}  |  Generated {timezone.now():%Y-%m-%d}")
    rep = Report(title=title, kind=kind, fmt=fmt, year=run.year, period=period, created_by=user)
    rep.file.save(f"{kind}_{run.year}_{timezone.now():%Y%m%d%H%M%S}.{fmt}", ContentFile(data))
    return rep
