from django.conf import settings
from django.db import models


class Report(models.Model):
    class Kind(models.TextChoices):
        NATIONAL = "national", "National rankings"
        PROVINCIAL = "provincial", "Provincial rankings"
        DISTRICT = "district", "District rankings"
        MINISTRY = "ministry", "Ministry report"

    class Format(models.TextChoices):
        PDF = "pdf", "PDF"
        XLSX = "xlsx", "Excel"
        CSV = "csv", "CSV"

    title = models.CharField(max_length=200)
    kind = models.CharField(max_length=12, choices=Kind.choices)
    fmt = models.CharField(max_length=5, choices=Format.choices)
    year = models.PositiveIntegerField()
    period = models.CharField(max_length=12, default="manual", help_text="manual / monthly / quarterly / yearly")
    file = models.FileField(upload_to="reports/")
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL,
                                   related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.title
