"""CSV / Excel / PDF generation from plain row dicts (no Django imports)."""
import csv
import io

COLUMNS = [
    ("national_rank", "National"), ("provincial_rank", "Provincial"), ("district_rank", "District"),
    ("school", "School"), ("province", "Province"), ("district", "District name"),
    ("tier", "Tier"), ("overall", "Overall"), ("academic", "Academic"), ("teacher", "Teacher"),
    ("sports", "Sports"), ("certificate_hash", "Certificate hash"),
]


def to_csv(rows):
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow([label for _, label in COLUMNS])
    for r in rows:
        w.writerow([r.get(k, "") for k, _ in COLUMNS])
    return buf.getvalue().encode("utf-8")


def to_xlsx(rows, title="Rankings"):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    wb = Workbook()
    ws = wb.active
    ws.title = title[:31]
    ws.append([label for _, label in COLUMNS])
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="1F3A5F")
    for r in rows:
        ws.append([r.get(k, "") for k, _ in COLUMNS])
    for col in ws.columns:
        ws.column_dimensions[col[0].column_letter].width = min(40, max(len(str(c.value or "")) for c in col) + 2)
    ws.freeze_panes = "A2"
    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()


def to_pdf(rows, title="School Rankings", subtitle=""):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
    out = io.BytesIO()
    doc = SimpleDocTemplate(out, pagesize=landscape(A4), leftMargin=24, rightMargin=24, topMargin=24, bottomMargin=24)
    styles = getSampleStyleSheet()
    cols = [("national_rank", "Nat."), ("provincial_rank", "Prov."), ("district_rank", "Dist."), ("school", "School"),
            ("province", "Province"), ("tier", "Tier"), ("overall", "Overall"), ("certificate_hash", "Certificate")]
    data = [[label for _, label in cols]]
    for r in rows:
        row = [str(r.get(k, "")) for k, _ in cols]
        row[-1] = row[-1][:16] + "..." if row[-1] else ""
        data.append(row)
    table = Table(data, repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F3A5F")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F2F5F9")]),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#C9D1DC")),
    ]))
    story = [Paragraph(title, styles["Title"])]
    if subtitle:
        story.append(Paragraph(subtitle, styles["Normal"]))
    story += [Spacer(1, 10), table]
    doc.build(story)
    return out.getvalue()
