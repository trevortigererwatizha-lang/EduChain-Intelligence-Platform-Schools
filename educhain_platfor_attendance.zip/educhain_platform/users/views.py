from rest_framework import serializers
from rest_framework.exceptions import AuthenticationFailed
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework_simplejwt.views import TokenObtainPairView

from blockchain.service import audit

from . import totp


class MFATokenSerializer(TokenObtainPairSerializer):
    otp = serializers.CharField(required=False, write_only=True, allow_blank=True)

    def validate(self, attrs):
        otp = attrs.pop("otp", "") or ""
        data = super().validate(attrs)
        if self.user.mfa_enabled and not self.user.verify_otp(otp):
            raise AuthenticationFailed("A valid one-time code is required for this account.")
        return data


class MFATokenView(TokenObtainPairView):
    serializer_class = MFATokenSerializer


class MFASetupView(APIView):
    """Step 1: generate a secret and show the otpauth:// URI for an authenticator app."""
    permission_classes = [IsAuthenticated]

    def post(self, request, **kwargs):
        secret = totp.new_secret()
        request.user.set_mfa_secret(secret)
        request.user.mfa_enabled = False
        request.user.save(update_fields=["mfa_secret_encrypted", "mfa_enabled"])
        return Response({"secret": secret, "otpauth_uri": totp.provisioning_uri(secret, request.user.username)})


class MFAEnableView(APIView):
    """Step 2: confirm a code from the authenticator app to switch MFA on."""
    permission_classes = [IsAuthenticated]

    def post(self, request, **kwargs):
        if not request.user.verify_otp(request.data.get("otp", "")):
            return Response({"detail": "Invalid code."}, status=400)
        request.user.mfa_enabled = True
        request.user.save(update_fields=["mfa_enabled"])
        audit(request.user, "mfa_enabled", "user", request.user.pk, request=request)
        return Response({"detail": "MFA enabled."})
