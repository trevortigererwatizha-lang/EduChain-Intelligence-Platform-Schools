"""AES-256-GCM helpers for encrypting sensitive values at rest (e.g. MFA secrets).

FIELD_ENCRYPTION_KEY must be 32 random bytes, base64-encoded:
    python -c "import os,base64;print(base64.b64encode(os.urandom(32)).decode())"
"""
import base64
import hashlib
import os


def _key(raw=None):
    if raw is None:
        from django.conf import settings
        raw = settings.FIELD_ENCRYPTION_KEY
    key = base64.b64decode(raw)
    if len(key) != 32:
        raise ValueError("FIELD_ENCRYPTION_KEY must decode to exactly 32 bytes (AES-256)")
    return key


def dev_key_from_secret(secret):
    """Derive a stable 32-byte key for development only. Set a real key in production."""
    return base64.b64encode(hashlib.sha256(secret.encode()).digest()).decode()


def encrypt(plaintext, raw_key=None):
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    nonce = os.urandom(12)
    ct = AESGCM(_key(raw_key)).encrypt(nonce, plaintext.encode(), None)
    return base64.b64encode(nonce + ct).decode()


def decrypt(token, raw_key=None):
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    data = base64.b64decode(token)
    return AESGCM(_key(raw_key)).decrypt(data[:12], data[12:], None).decode()
