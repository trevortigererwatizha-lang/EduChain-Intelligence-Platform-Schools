from django.contrib.auth.models import AbstractUser
from django.db import models

from . import crypto, totp


class User(AbstractUser):
    class Role(models.TextChoices):
        SUPER_ADMIN = "super_admin", "Super Administrator"
        MINISTRY = "ministry", "Ministry Official"
        SCHOOL_ADMIN = "school_admin", "School Administrator"
        PARENT = "parent", "Parent"
        RESEARCHER = "researcher", "Researcher"

    role = models.CharField(max_length=20, choices=Role.choices, default=Role.PARENT)
    school = models.ForeignKey("schools.School", null=True, blank=True, on_delete=models.SET_NULL,
                               related_name="staff", help_text="Required for school administrators.")
    mfa_enabled = models.BooleanField(default=False)
    mfa_secret_encrypted = models.TextField(blank=True, editable=False)

    def set_mfa_secret(self, secret):
        self.mfa_secret_encrypted = crypto.encrypt(secret)

    def get_mfa_secret(self):
        return crypto.decrypt(self.mfa_secret_encrypted) if self.mfa_secret_encrypted else ""

    def verify_otp(self, code):
        secret = self.get_mfa_secret()
        return bool(secret) and totp.verify(secret, code)

    @property
    def is_ministry_or_admin(self):
        return self.is_superuser or self.role in (self.Role.SUPER_ADMIN, self.Role.MINISTRY)
