from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import User


@admin.register(User)
class EduUserAdmin(UserAdmin):
    list_display = ("username", "email", "role", "school", "mfa_enabled", "is_active")
    list_filter = ("role", "mfa_enabled", "is_active")
    fieldsets = UserAdmin.fieldsets + (("EduChain", {"fields": ("role", "school", "mfa_enabled")}),)
    add_fieldsets = UserAdmin.add_fieldsets + (("EduChain", {"fields": ("role", "school")}),)
