"""RFC 6238 TOTP (pure standard library) for multi-factor authentication."""
import base64
import hashlib
import hmac
import secrets
import struct
import time


def new_secret():
    return base64.b32encode(secrets.token_bytes(20)).decode()


def _code(secret, counter, digits=6):
    key = base64.b32decode(secret, casefold=True)
    mac = hmac.new(key, struct.pack(">Q", counter), hashlib.sha1).digest()
    off = mac[-1] & 0x0F
    num = (struct.unpack(">I", mac[off:off + 4])[0] & 0x7FFFFFFF) % (10 ** digits)
    return str(num).zfill(digits)


def totp(secret, at=None, step=30):
    return _code(secret, int((time.time() if at is None else at) // step))


def verify(secret, code, at=None, step=30, window=1):
    now = int((time.time() if at is None else at) // step)
    code = str(code).strip()
    return any(hmac.compare_digest(_code(secret, now + d), code)
               for d in range(-window, window + 1) if now + d >= 0)


def provisioning_uri(secret, account, issuer="EduChain"):
    return f"otpauth://totp/{issuer}:{account}?secret={secret}&issuer={issuer}"
