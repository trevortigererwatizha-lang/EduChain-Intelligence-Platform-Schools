from rest_framework.permissions import SAFE_METHODS, BasePermission

SUPER, MINISTRY, SCHOOL_ADMIN, PARENT, RESEARCHER = (
    "super_admin", "ministry", "school_admin", "parent", "researcher")


def role_required(*roles, allow_safe_public=False):
    """Build a DRF permission class allowing the given roles (superusers always pass)."""
    class _RolePermission(BasePermission):
        def has_permission(self, request, view):
            if allow_safe_public and request.method in SAFE_METHODS:
                return True
            u = request.user
            return bool(u and u.is_authenticated and (u.is_superuser or u.role in roles))
    return _RolePermission


IsSuperAdmin = role_required(SUPER)
IsMinistryOrAdmin = role_required(SUPER, MINISTRY)
IsSchoolStaffOrAbove = role_required(SUPER, MINISTRY, SCHOOL_ADMIN)
IsResearcherOrAbove = role_required(SUPER, MINISTRY, RESEARCHER)
IsAnyRole = role_required(SUPER, MINISTRY, SCHOOL_ADMIN, PARENT, RESEARCHER)
