"""Pure hash-chained ledger primitives (no Django imports).

Each block commits to the previous block's hash, so changing any stored record
invalidates every later block. Blocks are also HMAC-signed by the node and use
a small proof-of-work so that rewriting history has a cost.
"""
import hashlib
import hmac
import json

GENESIS_PREV = "0" * 64


def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str)


def block_hash(index, timestamp, record_type, payload, prev_hash, nonce):
    body = canonical([index, timestamp, record_type, payload, prev_hash, nonce])
    return hashlib.sha256(body.encode()).hexdigest()


def mine(index, timestamp, record_type, payload, prev_hash, difficulty=2):
    target = "0" * difficulty
    nonce = 0
    while True:
        h = block_hash(index, timestamp, record_type, payload, prev_hash, nonce)
        if h.startswith(target):
            return nonce, h
        nonce += 1


def sign(hash_hex, key):
    return hmac.new(key.encode(), hash_hex.encode(), hashlib.sha256).hexdigest()


def verify_blocks(blocks, difficulty=2, key=None):
    """blocks: iterable of dicts (index, timestamp, record_type, payload, prev_hash, nonce, hash[, signature]).

    Returns (ok, first_bad_index_or_None, reason).
    """
    prev_hash, expected_index = GENESIS_PREV, 0
    target = "0" * difficulty
    for b in blocks:
        if b["index"] != expected_index:
            return False, b["index"], "index gap or reorder"
        if b["prev_hash"] != prev_hash:
            return False, b["index"], "previous-hash link broken"
        h = block_hash(b["index"], b["timestamp"], b["record_type"], b["payload"], b["prev_hash"], b["nonce"])
        if h != b["hash"]:
            return False, b["index"], "block contents do not match their hash"
        if not h.startswith(target):
            return False, b["index"], "proof-of-work not satisfied"
        if key is not None and b.get("signature") and not hmac.compare_digest(b["signature"], sign(h, key)):
            return False, b["index"], "invalid node signature"
        prev_hash, expected_index = b["hash"], expected_index + 1
    return True, None, "ok"
