from django.conf import settings
from django.db import models


class Block(models.Model):
    index = models.PositiveIntegerField(unique=True)
    timestamp = models.CharField(max_length=40, help_text="ISO-8601 UTC string; part of the hashed content")
    record_type = models.CharField(max_length=30, db_index=True)
    payload = models.JSONField()
    prev_hash = models.CharField(max_length=64)
    nonce = models.PositiveBigIntegerField()
    hash = models.CharField(max_length=64, unique=True)
    signature = models.CharField(max_length=64, blank=True)

    class Meta:
        ordering = ["index"]

    def __str__(self):
        return f"#{self.index} {self.record_type} {self.hash[:10]}"


class LedgerNode(models.Model):
    """A participating validator node (for the multi-node / Hyperledger deployment path)."""
    name = models.CharField(max_length=100, unique=True)
    url = models.URLField(blank=True)
    organisation = models.CharField(max_length=150, blank=True)
    is_active = models.BooleanField(default=True)
    last_sync = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return self.name


class AuditLog(models.Model):
    """Application audit trail: who did what, and when."""
    user = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    action = models.CharField(max_length=60, db_index=True)
    object_type = models.CharField(max_length=60, blank=True)
    object_id = models.CharField(max_length=60, blank=True)
    detail = models.JSONField(default=dict, blank=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.created_at:%Y-%m-%d %H:%M} {self.action}"
