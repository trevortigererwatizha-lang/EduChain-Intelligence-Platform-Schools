from django.contrib import admin

from .models import AuditLog, Block, LedgerNode


class ReadOnlyAdmin(admin.ModelAdmin):
    """Ledger and audit entries are append-only: no add / change / delete in the admin."""
    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(Block)
class BlockAdmin(ReadOnlyAdmin):
    list_display = ("index", "record_type", "timestamp", "hash")
    list_filter = ("record_type",)


@admin.register(AuditLog)
class AuditLogAdmin(ReadOnlyAdmin):
    list_display = ("created_at", "user", "action", "object_type", "object_id", "ip_address")
    list_filter = ("action",)


@admin.register(LedgerNode)
class LedgerNodeAdmin(admin.ModelAdmin):
    list_display = ("name", "organisation", "url", "is_active", "last_sync")
