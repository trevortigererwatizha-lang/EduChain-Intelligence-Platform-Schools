"""Ledger persistence on top of the pure primitives in ledger.py.

This is a built-in, permissioned hash-chain ledger stored in the application
database. It gives tamper-evidence for rankings, methodologies and validation
records. It is NOT a Hyperledger Fabric or Ethereum network: to anchor on one,
implement the same two functions (append / verify_chain) against that backend.
"""
import json
from datetime import timezone as dt_tz

from django.conf import settings
from django.db import transaction
from django.utils import timezone

from . import ledger
from .models import AuditLog, Block


def _now_iso():
    return timezone.now().astimezone(dt_tz.utc).isoformat()


def _create(index, record_type, payload, prev_hash):
    payload = json.loads(ledger.canonical(payload))  # force JSON-safe types, same as DB round trip
    ts = _now_iso()
    nonce, h = ledger.mine(index, ts, record_type, payload, prev_hash, settings.LEDGER_DIFFICULTY)
    return Block.objects.create(index=index, timestamp=ts, record_type=record_type, payload=payload,
                                prev_hash=prev_hash, nonce=nonce, hash=h,
                                signature=ledger.sign(h, settings.LEDGER_SIGNING_KEY))


def append(record_type, payload):
    with transaction.atomic():
        last = Block.objects.select_for_update().order_by("-index").first()
        if last is None:
            last = _create(0, "genesis", {"network": "EduChain", "note": "genesis block"}, ledger.GENESIS_PREV)
        return _create(last.index + 1, record_type, payload, last.hash)


def verify_chain():
    blocks = list(Block.objects.order_by("index").values(
        "index", "timestamp", "record_type", "payload", "prev_hash", "nonce", "hash", "signature"))
    ok, bad_index, reason = ledger.verify_blocks(blocks, settings.LEDGER_DIFFICULTY, settings.LEDGER_SIGNING_KEY)
    return {"valid": ok, "blocks": len(blocks), "first_invalid_index": bad_index, "reason": reason}


def audit(user, action, object_type="", object_id="", detail=None, request=None):
    ip = None
    if request is not None:
        fwd = request.META.get("HTTP_X_FORWARDED_FOR", "")
        ip = (fwd.split(",")[0].strip() if fwd else request.META.get("REMOTE_ADDR")) or None
    return AuditLog.objects.create(
        user=user if getattr(user, "is_authenticated", False) else None,
        action=action, object_type=object_type, object_id=str(object_id), detail=detail or {}, ip_address=ip)
