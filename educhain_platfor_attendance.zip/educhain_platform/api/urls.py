from django.urls import include, path
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import TokenRefreshView

from users.views import MFAEnableView, MFASetupView, MFATokenView

from . import views

router = DefaultRouter()
router.register("schools", views.SchoolViewSet, basename="school")
router.register("blockchain/nodes", views.NodeViewSet, basename="node")

urlpatterns = [
    # auth (JWT + optional TOTP MFA)
    path("auth/token/", MFATokenView.as_view()),
    path("auth/token/refresh/", TokenRefreshView.as_view()),
    path("auth/mfa/setup/", MFASetupView.as_view()),
    path("auth/mfa/enable/", MFAEnableView.as_view()),
    # schools & data verification
    path("indicators/", views.IndicatorReviewView.as_view()),
    path("indicators/<int:pk>/<str:decision>/", views.IndicatorReviewView.as_view()),
    # rankings
    path("rankings/", views.RankingListView.as_view()),
    path("rankings/methodology/", views.MethodologyView.as_view()),
    path("rankings/config/", views.RankingConfigView.as_view()),
    path("rankings/compute/", views.ComputeRankingView.as_view()),
    path("rankings/runs/", views.RunListView.as_view()),
    path("rankings/runs/<int:pk>/publish/", views.RunPublishView.as_view()),
    path("rankings/<int:pk>/", views.RankingDetailView.as_view()),
    # blockchain
    path("blockchain/blocks/", views.BlockListView.as_view()),
    path("blockchain/verify/", views.ChainVerifyView.as_view()),
    path("blockchain/certificate/<int:pk>/", views.CertificateView.as_view()),
    # analytics, predictions, insights, reports
    path("analytics/<str:kind>/", views.AnalyticsView.as_view()),
    path("predictions/<int:pk>/", views.PredictionView.as_view()),
    path("insights/<int:pk>/", views.InsightView.as_view()),
    path("reports/rankings/", views.ReportDownloadView.as_view()),
    path("", include(router.urls)),
]
