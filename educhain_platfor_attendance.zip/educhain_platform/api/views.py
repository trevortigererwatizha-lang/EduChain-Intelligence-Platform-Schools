from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import NotFound, PermissionDenied
from rest_framework.pagination import LimitOffsetPagination
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from analytics import services as an
from blockchain import service as chain
from blockchain.models import Block, LedgerNode
from rankings import scoring, services as rk
from rankings.models import RankingConfig, RankingRun, SchoolRanking
from reports import services as rep
from schools import services as sch
from schools.models import School, SchoolIndicators
from users import permissions as perm

from . import serializers as ser


def _staff_for(request, school):
    u = request.user
    return u.is_ministry_or_admin or (u.role == perm.SCHOOL_ADMIN and u.school_id == school.pk)


# ----------------------------------------------------------------------------- schools
class SchoolViewSet(viewsets.ModelViewSet):
    serializer_class = ser.SchoolSerializer
    permission_classes = [perm.role_required(perm.SUPER, perm.MINISTRY, allow_safe_public=True)]

    def get_queryset(self):
        qs = School.objects.filter(is_active=True)
        p = self.request.query_params
        for field in ("province", "district", "school_type"):
            if p.get(field):
                qs = qs.filter(**{f"{field}__iexact": p[field]})
        if p.get("q"):
            qs = qs.filter(name__icontains=p["q"])
        return qs

    def perform_create(self, serializer):
        obj = serializer.save()
        chain.audit(self.request.user, "school_created", "school", obj.pk, request=self.request)

    @action(detail=True, methods=["get", "post"], url_path="indicators", permission_classes=[IsAuthenticated])
    def indicators(self, request, pk=None, **kwargs):
        school = self.get_object()
        if not _staff_for(request, school):
            raise PermissionDenied("Only this school's administrators or the ministry can access its indicators.")
        if request.method == "GET":
            return Response(ser.IndicatorRecordSerializer(school.indicators.all(), many=True).data)
        year = request.data.get("year")
        if not year:
            return Response({"year": "required"}, status=400)
        s = ser.IndicatorSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        data = {k: v for k, v in s.validated_data.items() if k != "year"}
        try:
            obj = sch.submit_indicators(school, int(year), data, request.user)
        except ValueError as e:
            return Response({"detail": str(e)}, status=400)
        return Response(ser.IndicatorRecordSerializer(obj).data, status=201)

    @action(detail=True, methods=["get"], url_path="benchmark", permission_classes=[IsAuthenticated])
    def benchmark(self, request, pk=None, **kwargs):
        school = self.get_object()
        if not _staff_for(request, school):
            raise PermissionDenied("Benchmarking is available to this school's administrators and the ministry.")
        run = an.published_run(request.query_params.get("year"))
        r = run.rankings.filter(school=school).first() if run else None
        if not r:
            return Response({"detail": "School not ranked yet."}, status=404)
        med = an.national_median(run)
        return Response({"year": run.year, "school": r.scores, "national_median": med,
                         "gap": {c: round(r.scores[c] - med[c], 2) for c in med}})


class IndicatorReviewView(APIView):
    """Ministry: GET ?status=submitted lists the queue; POST .../<id>/verify|reject/ decides."""
    permission_classes = [perm.IsMinistryOrAdmin]

    def get(self, request, **kwargs):
        qs = SchoolIndicators.objects.select_related("school").filter(status=request.query_params.get("status", "submitted"))
        return Response(ser.IndicatorRecordSerializer(qs, many=True).data)

    def post(self, request, pk, decision, **kwargs):
        obj = get_object_or_404(SchoolIndicators, pk=pk)
        try:
            if decision == "verify":
                sch.verify_indicators(obj, request.user)
            elif decision == "reject":
                sch.reject_indicators(obj, request.user, request.data.get("note", ""))
            else:
                return Response({"detail": "decision must be verify or reject"}, status=400)
        except ValueError as e:
            return Response({"detail": str(e)}, status=400)
        return Response(ser.IndicatorRecordSerializer(obj).data)


# ----------------------------------------------------------------------------- rankings
class RankingListView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, **kwargs):
        p = request.query_params
        run = an.published_run(p.get("year"))
        if not run:
            return Response({"count": 0, "results": []})
        qs = run.rankings.select_related("school", "run")
        if p.get("province"):
            qs = qs.filter(school__province__iexact=p["province"])
        if p.get("district"):
            qs = qs.filter(school__district__iexact=p["district"])
        if p.get("tier"):
            qs = qs.filter(tier__iexact=p["tier"])
        if p.get("q"):
            qs = qs.filter(school__name__icontains=p["q"])
        order = {"province": "provincial_rank", "district": "district_rank"}.get(p.get("level"), "national_rank")
        qs = qs.order_by(order, "school__name")
        pager = LimitOffsetPagination()
        page = pager.paginate_queryset(qs, request, view=self)
        return pager.get_paginated_response(ser.RankingSerializer(page, many=True).data)


class RankingDetailView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, pk, **kwargs):
        r = get_object_or_404(SchoolRanking.objects.select_related("school", "run"), pk=pk,
                              run__status=RankingRun.Status.PUBLISHED)
        return Response(ser.RankingSerializer(r).data)


class MethodologyView(APIView):
    """Public: the weights and rules currently in force, and the hash recorded for the latest run."""
    permission_classes = [AllowAny]

    def get(self, request, **kwargs):
        run = an.published_run()
        doc = scoring.methodology_document(rk.active_weights())
        return Response({"active": doc, "active_hash": scoring.document_hash(doc),
                         "latest_published": {"year": run.year, "methodology_hash": run.methodology_hash,
                                              "ledger_block": run.methodology_block_index} if run else None})


class RankingConfigView(APIView):
    """GET: current weights (public). PUT {"weights": {...}}: super admin only; recorded on the ledger."""
    permission_classes = [perm.role_required(perm.SUPER, allow_safe_public=True)]

    def get(self, request, **kwargs):
        return Response({"weights": rk.active_weights(), "categories": scoring.CATEGORIES})

    def put(self, request, **kwargs):
        try:
            cfg = rk.set_active_weights(request.data.get("weights"), request.user, request.data.get("name", "Custom"))
        except (ValueError, TypeError, AttributeError) as e:
            return Response({"detail": str(e)}, status=400)
        return Response({"weights": cfg.weights})


class ComputeRankingView(APIView):
    permission_classes = [perm.IsMinistryOrAdmin]

    def post(self, request, **kwargs):
        try:
            run = rk.compute_run(int(request.data.get("year")), request.user, request.data.get("weights"))
        except (ValueError, TypeError) as e:
            return Response({"detail": str(e)}, status=400)
        return Response(ser.RunSerializer(run).data, status=201)


class RunListView(APIView):
    permission_classes = [perm.IsMinistryOrAdmin]

    def get(self, request, **kwargs):
        return Response(ser.RunSerializer(RankingRun.objects.all(), many=True).data)


class RunPublishView(APIView):
    permission_classes = [perm.IsMinistryOrAdmin]

    def post(self, request, pk, **kwargs):
        run = get_object_or_404(RankingRun, pk=pk)
        try:
            rk.publish_run(run, request.user)
        except ValueError as e:
            return Response({"detail": str(e)}, status=400)
        return Response(ser.RunSerializer(run).data)


# ----------------------------------------------------------------------------- blockchain
class BlockListView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, **kwargs):
        qs = Block.objects.all()
        if request.query_params.get("type"):
            qs = qs.filter(record_type=request.query_params["type"])
        pager = LimitOffsetPagination()
        page = pager.paginate_queryset(qs, request, view=self)
        return pager.get_paginated_response(ser.BlockSerializer(page, many=True).data)


class ChainVerifyView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, **kwargs):
        return Response(chain.verify_chain())


class CertificateView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, pk, **kwargs):
        r = get_object_or_404(SchoolRanking.objects.select_related("school", "run"), pk=pk,
                              run__status=RankingRun.Status.PUBLISHED)
        return Response({"certificate": r.certificate_payload(), "verification": rk.verify_ranking(r)})


class NodeViewSet(viewsets.ModelViewSet):
    queryset = LedgerNode.objects.all()
    serializer_class = ser.NodeSerializer
    permission_classes = [perm.IsSuperAdmin]


# ----------------------------------------------------------------------------- analytics / predictions / insights
def _run_or_404(request):
    run = an.published_run(request.query_params.get("year"))
    if not run:
        raise NotFound("No published ranking yet.")
    return run


class AnalyticsView(APIView):
    """GET /analytics/<summary|heatmap|map|clusters|factors|tier-model|dataset>/"""
    permission_classes = [AllowAny]

    def get(self, request, kind, **kwargs):
        run = _run_or_404(request)
        if kind == "summary":
            return Response(an.national_summary(run))
        if kind == "heatmap":
            return Response(an.heatmap(run))
        if kind == "map":
            return Response(an.map_points(run))
        if kind == "clusters":
            return Response(an.clusters(run, int(request.query_params.get("k", 4))))
        if kind == "factors":
            return Response(an.factors(run))
        if kind == "tier-model":
            return Response(an.tier_model(run))
        if kind == "dataset":
            if not (request.user.is_authenticated and perm.IsResearcherOrAbove().has_permission(request, self)):
                raise PermissionDenied("Researcher access required.")
            chain.audit(request.user, "dataset_accessed", "ranking_run", run.pk, request=request)
            return Response(an.anonymised_dataset(run))
        return Response({"detail": "unknown analytics view"}, status=404)


class PredictionView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, pk, **kwargs):
        school = get_object_or_404(School, pk=pk, is_active=True)
        out = an.predict_school(school, int(request.query_params.get("horizon", 3)))
        return Response(out, status=404 if "error" in out else 200)


class InsightView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, pk, **kwargs):
        school = get_object_or_404(School, pk=pk, is_active=True)
        out = an.school_insight(school, request.query_params.get("year"))
        return Response(out, status=404 if "error" in out else 200)


# ----------------------------------------------------------------------------- reports
class ReportDownloadView(APIView):
    """GET /reports/rankings/?fmt=pdf|xlsx|csv&level=national|province|district&province=&district=&year="""
    permission_classes = [perm.IsAnyRole]

    def get(self, request, **kwargs):
        p = request.query_params
        run = _run_or_404(request)
        fmt = p.get("fmt", "pdf")
        level = p.get("level", "national")
        if level in ("province", "district") and not (p.get("province") or p.get("district")):
            return Response({"detail": "province (and district for district level) required"}, status=400)
        try:
            rows = rep.ranking_rows(run, "provincial" if level == "province" else level, p.get("province"), p.get("district"))
            title = f"{level.title()} school rankings {run.year}"
            data = rep.render(rows, fmt, title, f"Methodology hash: {run.methodology_hash}")
        except ValueError as e:
            return Response({"detail": str(e)}, status=400)
        chain.audit(request.user, "report_downloaded", "ranking_run", run.pk, {"fmt": fmt, "level": level}, request)
        resp = HttpResponse(data, content_type=rep.CONTENT_TYPES[fmt])
        resp["Content-Disposition"] = f'attachment; filename="rankings_{run.year}_{level}.{fmt}"'
        return resp
