from rest_framework import serializers

from blockchain.models import Block, LedgerNode
from rankings.models import RankingRun, SchoolRanking
from schools.models import School, SchoolIndicators


class SchoolSerializer(serializers.ModelSerializer):
    class Meta:
        model = School
        fields = ["id", "name", "registration_number", "latitude", "longitude", "school_type", "boarding_type",
                  "province", "district", "email", "website", "logo", "is_active"]


class IndicatorSerializer(serializers.ModelSerializer):
    class Meta:
        model = SchoolIndicators
        exclude = ["school", "submitted_by", "verified_by", "verified_at", "status", "data_hash", "review_note",
                   "updated_at"]
        read_only_fields = ["id"]


class IndicatorRecordSerializer(serializers.ModelSerializer):
    school_name = serializers.CharField(source="school.name", read_only=True)

    class Meta:
        model = SchoolIndicators
        fields = ["id", "school", "school_name", "year", "status", "verified_at", "review_note", "data_hash"]


class RankingSerializer(serializers.ModelSerializer):
    school_name = serializers.CharField(source="school.name", read_only=True)
    province = serializers.CharField(source="school.province", read_only=True)
    district = serializers.CharField(source="school.district", read_only=True)
    year = serializers.IntegerField(source="run.year", read_only=True)
    rank_change = serializers.IntegerField(read_only=True)

    class Meta:
        model = SchoolRanking
        fields = ["id", "year", "school", "school_name", "province", "district", "overall", "scores", "national_rank",
                  "provincial_rank", "district_rank", "previous_rank", "rank_change", "tier", "block_index",
                  "certificate_hash"]


class RunSerializer(serializers.ModelSerializer):
    class Meta:
        model = RankingRun
        fields = ["id", "year", "status", "weights", "methodology_hash", "methodology_block_index", "created_at",
                  "published_at"]


class BlockSerializer(serializers.ModelSerializer):
    class Meta:
        model = Block
        fields = ["index", "timestamp", "record_type", "payload", "prev_hash", "nonce", "hash", "signature"]


class NodeSerializer(serializers.ModelSerializer):
    class Meta:
        model = LedgerNode
        fields = "__all__"
