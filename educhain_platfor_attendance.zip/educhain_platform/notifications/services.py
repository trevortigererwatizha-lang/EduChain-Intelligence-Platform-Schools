from django.contrib.auth import get_user_model
from django.db.models import Q

from .models import Notification


def notify_roles(roles, title, message=""):
    """Create an in-app notification for every active user holding one of the roles (and superusers)."""
    User = get_user_model()
    users = User.objects.filter(is_active=True).filter(Q(role__in=roles) | Q(is_superuser=True))
    Notification.objects.bulk_create([Notification(user=u, title=title, message=message) for u in users])


def notify_user(user, title, message=""):
    Notification.objects.create(user=user, title=title, message=message)
