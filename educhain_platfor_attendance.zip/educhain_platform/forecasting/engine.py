"""Pure time-series forecasting (numpy only).

Uses Holt's linear exponential smoothing with a grid-searched alpha/beta, and
falls back to a straight-line fit for very short histories. ARIMA, Prophet and
LSTM are not used here; with a handful of annual points per school they add
complexity without adding accuracy.
"""
import math

import numpy as np


def forecast(values, horizon=3, lo=None, hi=None):
    y = np.asarray([float(v) for v in values], dtype=float)
    n = len(y)
    if n == 0:
        raise ValueError("need at least one observation")
    if n == 1:
        pts = [float(y[0])] * horizon
        return _pack("flat (1 point)", pts, [0.0] * horizon, lo, hi)
    if n < 4:
        slope, intercept = np.polyfit(np.arange(n), y, 1)
        resid = y - (slope * np.arange(n) + intercept)
        sd = float(resid.std()) if n > 2 else 0.0
        pts = [float(intercept + slope * (n - 1 + h)) for h in range(1, horizon + 1)]
        return _pack("linear trend", pts, [sd * math.sqrt(h) * 1.96 for h in range(1, horizon + 1)], lo, hi)

    best = None
    for alpha in np.linspace(0.1, 0.9, 9):
        for beta in np.linspace(0.1, 0.9, 9):
            level, trend = y[0], y[1] - y[0]
            sse, errs = 0.0, []
            for t in range(1, n):
                pred = level + trend
                err = y[t] - pred
                errs.append(err)
                sse += err * err
                new_level = alpha * y[t] + (1 - alpha) * (level + trend)
                trend = beta * (new_level - level) + (1 - beta) * trend
                level = new_level
            if best is None or sse < best[0]:
                best = (sse, level, trend, float(np.std(errs)))
    _, level, trend, sd = best
    pts = [float(level + h * trend) for h in range(1, horizon + 1)]
    return _pack("Holt linear smoothing", pts, [1.96 * sd * math.sqrt(h) for h in range(1, horizon + 1)], lo, hi)


def _pack(method, pts, margins, lo, hi):
    clip = lambda v: max(lo, v) if lo is not None and v < lo else (min(hi, v) if hi is not None and v > hi else v)
    return {
        "method": method,
        "forecast": [round(clip(p), 2) for p in pts],
        "lower": [round(clip(p - m), 2) for p, m in zip(pts, margins)],
        "upper": [round(clip(p + m), 2) for p, m in zip(pts, margins)],
    }


def teachers_required(enrollment_forecast, target_ratio=25.0):
    return [int(math.ceil(max(e, 0) / target_ratio)) for e in enrollment_forecast]
