"""Pure helpers for year-on-year comparison and similarity (no Django imports)."""
import math

TIER_ORDER = ["Emerging", "Bronze", "Silver", "Gold", "Platinum"]


def tier_transitions(prev, curr):
    """prev/curr: {school_id: tier}. Only schools present in both years are compared."""
    matrix = {a: {b: 0 for b in TIER_ORDER} for a in TIER_ORDER}
    up = down = same = 0
    for sid, now in curr.items():
        before = prev.get(sid)
        if before is None or before not in matrix or now not in matrix[before]:
            continue
        matrix[before][now] += 1
        d = TIER_ORDER.index(now) - TIER_ORDER.index(before)
        up, down, same = up + (d > 0), down + (d < 0), same + (d == 0)
    return {"matrix": matrix, "up": up, "down": down, "same": same, "order": TIER_ORDER}


def movers(prev_rank, curr_rank, n=5):
    """Biggest rank improvements and falls. Ranks are 1 = best, so improvement = prev - curr."""
    deltas = [(sid, prev_rank[sid] - r) for sid, r in curr_rank.items() if sid in prev_rank]
    risers = sorted([d for d in deltas if d[1] > 0], key=lambda d: (-d[1], curr_rank[d[0]]))[:n]
    fallers = sorted([d for d in deltas if d[1] < 0], key=lambda d: (d[1], curr_rank[d[0]]))[:n]
    return {"risers": risers, "fallers": fallers}


def percent_change(old, new):
    if old in (None, 0):
        return None
    return round((new - old) / abs(old) * 100.0, 1)


def nearest(target, others, k=5):
    """others: {id: vector}. Returns the k ids closest (Euclidean) to the target vector, with distances."""
    dist = [(sid, math.dist(target, vec)) for sid, vec in others.items()]
    return sorted(dist, key=lambda d: (d[1], d[0]))[:k]


def personal_score(scores, weights):
    """Re-weight category scores by a person's own priorities (weights need not sum to 1)."""
    total = sum(w for w in weights.values() if w > 0)
    if total <= 0:
        return None
    return sum(scores.get(c, 0.0) * w for c, w in weights.items() if w > 0) / total
