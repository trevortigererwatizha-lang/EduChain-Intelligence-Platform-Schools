"""Database-aware analytics: assembles data from published rankings and applies the pure ml/insight modules.

Aggregation here uses pandas/numpy in-process. Apache Spark, Hadoop and Kafka are not wired in;
the functions that take a run and return plain dicts are the natural seams to move onto Spark later.
"""
import hashlib
import hmac
from collections import Counter, defaultdict

import numpy as np
from django.conf import settings

from forecasting import engine
from rankings import insights
from rankings.models import RankingRun, SchoolRanking
from rankings.scoring import CATEGORIES
from schools.models import SchoolIndicators

from . import ml

CORE = [c for c in CATEGORIES if c != "community"]


def published_run(year=None):
    qs = RankingRun.objects.filter(status=RankingRun.Status.PUBLISHED)
    if year not in (None, ""):
        try:
            return qs.filter(year=int(year)).first()
        except (TypeError, ValueError):
            return None  # a non-numeric ?year= is treated as "no such ranking", not a server error
    return qs.order_by("-year").first()


def _vec(r, cats=CORE):
    return [r.scores.get(c, 0.0) for c in cats]


def national_summary(run):
    rows = list(run.rankings.select_related("school"))
    brief = lambda r: {"school_id": r.school_id, "school": r.school.name, "province": r.school.province,
                       "national_rank": r.national_rank, "overall": round(r.overall, 2), "tier": r.tier}
    by_prov = defaultdict(list)
    for r in rows:
        by_prov[r.school.province].append(r.overall)
    growing = sorted([r for r in rows if r.rank_change is not None], key=lambda r: (-r.rank_change, r.national_rank))
    return {
        "year": run.year, "schools_ranked": len(rows),
        "national_average": round(float(np.mean([r.overall for r in rows])), 2) if rows else None,
        "tier_counts": dict(Counter(r.tier for r in rows)),
        "province_averages": {p: round(float(np.mean(v)), 2) for p, v in sorted(by_prov.items())},
        "top_overall": [brief(r) for r in rows[:10]],
        "top_growing": [{**brief(r), "rank_change": r.rank_change} for r in growing[:5] if r.rank_change > 0],
        "best_academic": [{**brief(r), "score": round(r.scores["academic"], 2)}
                          for r in sorted(rows, key=lambda r: -r.scores["academic"])[:5]],
        "best_sports": [{**brief(r), "score": round(r.scores["sports"], 2)}
                        for r in sorted(rows, key=lambda r: -r.scores["sports"])[:5]],
    }


def heatmap(run):
    cells = defaultdict(lambda: defaultdict(list))
    for r in run.rankings.select_related("school"):
        for c in CORE:
            cells[r.school.province][c].append(r.scores.get(c, 0))
    return {"categories": CORE, "provinces": sorted(cells),
            "values": {p: {c: round(float(np.mean(cells[p][c])), 1) for c in CORE} for p in sorted(cells)}}


def map_points(run):
    return [{"id": r.school_id, "name": r.school.name, "lat": r.school.latitude, "lng": r.school.longitude,
             "rank": r.national_rank, "tier": r.tier, "overall": round(r.overall, 1)}
            for r in run.rankings.select_related("school") if r.school.latitude is not None]


def national_median(run):
    rows = list(run.rankings.all())
    return {c: float(np.median([r.scores.get(c, 0) for r in rows])) for c in CATEGORIES} if rows else {}


def clusters(run, k=4):
    rows = list(run.rankings.select_related("school"))
    if len(rows) < 2:
        return {"clusters": []}
    labels = ml.cluster_schools([_vec(r) for r in rows], k)
    groups = defaultdict(list)
    for r, lab in zip(rows, labels):
        groups[lab].append(r)
    ordered = sorted(groups.values(), key=lambda g: -np.mean([r.overall for r in g]))
    out = []
    for i, g in enumerate(ordered, 1):
        means = {c: round(float(np.mean([r.scores[c] for r in g])), 1) for c in CORE}
        out.append({"cluster": i, "size": len(g), "mean_overall": round(float(np.mean([r.overall for r in g])), 1),
                    "strongest": max(means, key=means.get), "weakest": min(means, key=means.get), "means": means,
                    "schools": [r.school.name for r in g][:12]})
    return {"clusters": out}


def _history_pairs():
    """(category scores in run N, overall in run N+1) for every school present in consecutive published runs."""
    runs = list(RankingRun.objects.filter(status=RankingRun.Status.PUBLISHED).order_by("year"))
    X, y = [], []
    for a, b in zip(runs, runs[1:]):
        nxt = {r.school_id: r.overall for r in b.rankings.all()}
        for r in a.rankings.all():
            if r.school_id in nxt:
                X.append(_vec(r)); y.append(nxt[r.school_id])
    return X, y


def factors(run):
    X, y = _history_pairs()
    if len(X) >= 10:
        target = "next-year overall score from this year's category scores"
    else:
        rows = list(run.rankings.all())
        X, y = [_vec(r) for r in rows], [r.overall for r in rows]
        target = "current overall score (not enough multi-year history yet)"
    if len(X) < 5:
        return {"target": target, "importances": {}, "note": "Need at least 5 schools."}
    imp = ml.factor_importance(X, y, CORE)
    return {"target": target, "samples": len(X), "boosters_installed": ml.available_boosters(),
            "importances": {m: [{"factor": f, "importance": round(v, 4)} for f, v in vals] for m, vals in imp.items()}}


def tier_model(run):
    rows = list(run.rankings.all())
    res = ml.train_tier_classifier([_vec(r) for r in rows], [r.tier for r in rows]) if len(rows) >= 10 else None
    if not res:
        return {"trained": False, "note": "Need at least 10 schools spanning two or more tiers."}
    return {"trained": True, "best_model": res["name"], "cv_accuracy": res["cv_accuracy"], "all_scores": res["all_scores"]}


def anonymised_dataset(run):
    """No names, contact details or coordinates; schools are keyed by an HMAC pseudonym."""
    def ref(school_id):
        return hmac.new(settings.SECRET_KEY.encode(), f"school:{school_id}".encode(), hashlib.sha256).hexdigest()[:12]
    return [{"school_ref": ref(r.school_id), "year": run.year, "province": r.school.province,
             "school_type": r.school.school_type, "tier": r.tier, "overall": round(r.overall, 2),
             **{c: round(r.scores.get(c, 0), 2) for c in CATEGORIES}}
            for r in run.rankings.select_related("school")]


def predict_school(school, horizon=3):
    hist = list(SchoolRanking.objects.filter(school=school, run__status=RankingRun.Status.PUBLISHED)
                .select_related("run").order_by("run__year"))
    inds = list(SchoolIndicators.objects.filter(school=school, status=SchoolIndicators.Status.VERIFIED).order_by("year"))
    if not hist:
        return {"error": "No published ranking history for this school."}
    last_year = max(h.run.year for h in hist)
    years = [last_year + i for i in range(1, horizon + 1)]
    out = {"school": school.name, "years": years, "history_years": [h.run.year for h in hist]}
    out["overall_score"] = engine.forecast([h.overall for h in hist], horizon, 0, 100)
    if inds:
        out["exam_pass_rate"] = engine.forecast([i.exam_pass_rate for i in inds], horizon, 0, 100)
        out["enrollment"] = engine.forecast([i.total_enrollment for i in inds], horizon, 0, None)
        out["revenue"] = engine.forecast([i.annual_revenue for i in inds], horizon, 0, None)
        out["teachers_required"] = engine.teachers_required(out["enrollment"]["forecast"])
    X, y = _history_pairs()
    if len(X) >= 8:
        name, pred = ml.predict_next_overall(X, y, [_vec(hist[-1])])
        out["ml_next_year_overall"] = {"model": name, "prediction": round(pred[0], 2)}
    return out


def school_insight(school, year=None):
    run = published_run(year)
    if not run:
        return {"error": "No published ranking."}
    curr = run.rankings.filter(school=school).first()
    if not curr:
        return {"error": f"{school.name} is not ranked in {run.year}."}
    prev_run = RankingRun.objects.filter(status=RankingRun.Status.PUBLISHED, year__lt=run.year).order_by("-year").first()
    prev = prev_run.rankings.filter(school=school).first() if prev_run else None
    c = {"rank": curr.national_rank, "overall": curr.overall, "scores": curr.scores}
    p = {"rank": prev.national_rank, "overall": prev.overall, "scores": prev.scores} if prev else None
    explanation = insights.explain_rank_change(school.name, p, c)
    risks = insights.risk_factors(curr.scores, prev.scores if prev else None)
    recs = insights.recommendations(curr.scores, national_median(run))
    return {"school": school.name, "year": run.year, "tier": curr.tier, "explanation": explanation,
            "risk_factors": risks, "recommendations": recs,
            "executive_summary": insights.executive_summary(school.name, c, curr.tier, explanation, risks, recs)}
