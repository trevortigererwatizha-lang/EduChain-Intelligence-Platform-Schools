"""Machine-learning helpers (scikit-learn; no Django imports).

XGBoost, LightGBM and CatBoost are used only if they happen to be installed.
"""
import importlib

import numpy as np


def available_boosters():
    return [m for m in ("xgboost", "lightgbm", "catboost") if importlib.util.find_spec(m)]


def factor_importance(X, y, names, seed=0):
    """Which category scores best explain the target? Returns {model_name: [(feature, importance), ...]}."""
    from sklearn.ensemble import RandomForestRegressor
    X, y = np.asarray(X, float), np.asarray(y, float)
    out = {}
    rf = RandomForestRegressor(n_estimators=200, random_state=seed).fit(X, y)
    out["random_forest"] = sorted(zip(names, map(float, rf.feature_importances_)), key=lambda t: -t[1])
    boosters = available_boosters()
    if "xgboost" in boosters:
        from xgboost import XGBRegressor
        m = XGBRegressor(n_estimators=150, max_depth=3, random_state=seed, verbosity=0).fit(X, y)
        out["xgboost"] = sorted(zip(names, map(float, m.feature_importances_)), key=lambda t: -t[1])
    if "lightgbm" in boosters:
        from lightgbm import LGBMRegressor
        m = LGBMRegressor(n_estimators=150, max_depth=3, random_state=seed, verbose=-1).fit(X, y)
        imp = np.asarray(m.feature_importances_, float)
        imp = imp / imp.sum() if imp.sum() else imp
        out["lightgbm"] = sorted(zip(names, map(float, imp)), key=lambda t: -t[1])
    if "catboost" in boosters:
        from catboost import CatBoostRegressor
        m = CatBoostRegressor(iterations=150, depth=3, random_seed=seed, verbose=False).fit(X, y)
        imp = np.asarray(m.get_feature_importance(), float)
        imp = imp / imp.sum() if imp.sum() else imp
        out["catboost"] = sorted(zip(names, map(float, imp)), key=lambda t: -t[1])
    return out


def train_tier_classifier(X, labels, seed=0):
    """Compare decision tree, SVM and neural net by cross-validation; return the best fitted model."""
    from sklearn.model_selection import cross_val_score
    from sklearn.neural_network import MLPClassifier
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.svm import SVC
    from sklearn.tree import DecisionTreeClassifier

    X, labels = np.asarray(X, float), np.asarray(labels)
    classes, counts = np.unique(labels, return_counts=True)
    if len(classes) < 2:
        return None
    candidates = {
        "decision_tree": DecisionTreeClassifier(max_depth=4, random_state=seed),
        "svm": make_pipeline(StandardScaler(), SVC(random_state=seed)),
        "neural_network": make_pipeline(StandardScaler(), MLPClassifier((16,), max_iter=3000, random_state=seed)),
    }
    cv = int(min(5, counts.min()))
    results = {}
    if cv >= 2:
        for name, model in candidates.items():
            results[name] = float(cross_val_score(model, X, labels, cv=cv).mean())
        best = max(results, key=results.get)
        score = results[best]
    else:
        best, score = "decision_tree", None
    model = candidates[best].fit(X, labels)
    return {"name": best, "cv_accuracy": score, "all_scores": results, "model": model}


def cluster_schools(X, k=4, seed=0):
    from sklearn.cluster import KMeans
    from sklearn.preprocessing import StandardScaler
    X = np.asarray(X, float)
    k = max(1, min(k, len(X)))
    Z = StandardScaler().fit_transform(X)
    km = KMeans(n_clusters=k, n_init=10, random_state=seed).fit(Z)
    return [int(v) for v in km.labels_]


def predict_next_overall(Xtrain, ytrain, Xnew, seed=0):
    """Predict next-year overall score from this year's category scores."""
    from sklearn.ensemble import GradientBoostingRegressor
    from sklearn.linear_model import Ridge
    Xtrain, ytrain, Xnew = np.asarray(Xtrain, float), np.asarray(ytrain, float), np.asarray(Xnew, float)
    if len(Xtrain) >= 20:
        model, name = GradientBoostingRegressor(random_state=seed), "gradient_boosting"
    else:
        model, name = Ridge(alpha=1.0), "ridge"
    preds = model.fit(Xtrain, ytrain).predict(Xnew)
    return name, [float(np.clip(p, 0, 100)) for p in preds]
